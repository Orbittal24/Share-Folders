const { OPCUAClient, AttributeIds, DataType } = require("node-opcua");
const axios = require("axios");
const ExcelJS = require("exceljs");

// ------------------ Logger ------------------
const logToDashboard = (type, message) => {
  console.log(`[${type.toUpperCase()}] ${message}`);
};

// ------------------ Delay ------------------
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ------------------ Read OPC Config from Excel ------------------
const readOpcConfigFromExcel = async () => {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile("./opc_config.xlsx");

  const sheet = workbook.worksheets[0];
  const row = sheet.getRow(2); // first data row

  const opcIp = row.getCell(1).value;
  const opcPort = row.getCell(2).value;

  if (!opcIp || !opcPort) {
    throw new Error("OPC IP or Port missing in Excel");
  }

  return `opc.tcp://${opcIp}:${opcPort}`;
};

// ------------------ OPC UA Config ------------------
let opcuaConfig = {
  endpointUrl: "",
  module_barcode: "ns=4;i=6",
  modulebarcode_validation_start: "ns=4;i=7",
  modulebarcode_process_done: "ns=4;i=8",
  modulebarcode_result: "ns=4;i=9",
  mis_ready: "ns=4;i=10"
};

// ------------------ OPC Read ------------------
const readTag = async (session, nodeId) => {
  const result = await session.read({
    nodeId,
    attributeId: AttributeIds.Value
  });
  return result.value.value;
};

// ------------------ OPC Write ------------------
const writeTag = async (session, nodeId, dataType, value) => {
  await session.write({
    nodeId,
    attributeId: AttributeIds.Value,
    value: {
      value: { dataType, value }
    }
  });
};

// ------------------ OPC UA Client Runner ------------------
const runClient = async () => {
  // 🔹 Load OPC endpoint from Excel (once)
  try {
    opcuaConfig.endpointUrl = await readOpcConfigFromExcel();
    console.log(opcuaConfig.endpointUrl)
    logToDashboard(
      "success",
      `📘 OPC Endpoint Loaded: ${opcuaConfig.endpointUrl}`
    );
  } catch (err) {
    logToDashboard("error", `❌ Excel Config Error: ${err.message}`);
    process.exit(1);
  }

  while (true) {
    const client = OPCUAClient.create({
      endpointMustExist: false,
      keepSessionAlive: true,
      connectionStrategy: {
        initialDelay: 1000,
        maxRetry: 10
      },
      requestedSessionTimeout: 60000
    });

    let session = null;

    try {
      await client.connect(opcuaConfig.endpointUrl);
      logToDashboard("success", "✅ Connected to OPC UA server");

      session = await client.createSession();
      logToDashboard("success", "🟢 OPC UA session started");

      session.on("keepalive", () =>
        logToDashboard("info", "🔄 Session keepalive")
      );

      session.on("session_closed", () =>
        logToDashboard("warn", "⚠️ Session closed")
      );

      while (true) {
        const currentTagValues = {
          module_barcode: await readTag(session, opcuaConfig.module_barcode),
          modulebarcode_validation_start: await readTag(
            session,
            opcuaConfig.modulebarcode_validation_start
          ),
          modulebarcode_process_done: await readTag(
            session,
            opcuaConfig.modulebarcode_process_done
          ),
          modulebarcode_result: await readTag(
            session,
            opcuaConfig.modulebarcode_result
          ),
          mis_ready: await readTag(session, opcuaConfig.mis_ready)
        };

        logToDashboard(
          "info",
          `📋 OPC UA Values: ${JSON.stringify(currentTagValues)}`
        );

        // Always set MIS ready
        await writeTag(
          session,
          opcuaConfig.mis_ready,
          DataType.Boolean,
          true
        );

        const {
          module_barcode,
          modulebarcode_validation_start,
          modulebarcode_process_done,
          modulebarcode_result
        } = currentTagValues;

        // 🔹 Step 1: Validate module barcode
        if (modulebarcode_validation_start === 1) {
          try {
            const res = await axios.post(
              "https://mismainapp.tataautocomp.com:3242/validate_modulebarcode",
              { modulebarcode: module_barcode }
            );

            await writeTag(
              session,
              opcuaConfig.modulebarcode_validation_start,
              DataType.Int16,
              res.data.valid ? 2 : 3
            );

            logToDashboard(
              res.data.valid ? "success" : "warn",
              res.data.valid
                ? "✅ Barcode valid"
                : "❌ Barcode not found"
            );
          } catch (err) {
            logToDashboard("error", `🚨 Validation error: ${err.message}`);
          }
        }

        // 🔹 Step 2: Store result
        if (modulebarcode_process_done === 1) {
          try {
            await axios.post(
              "https://mismainapp.tataautocomp.com:3242/store_wel_insp_result",
              {
                modulebarcode_result,
                module_barcode
              }
            );

            await writeTag(
              session,
              opcuaConfig.modulebarcode_process_done,
              DataType.Int16,
              2
            );

            logToDashboard("success", "✅ Result stored");
          } catch (err) {
            logToDashboard("error", `🚨 Store failed: ${err.message}`);
          }
        }

        await delay(5000);
      }
    } catch (err) {
      logToDashboard("error", `❌ OPC UA Error: ${err.message}`);
    } finally {
      try {
        if (session) await session.close();
        await client.disconnect();
      } catch (e) {
        logToDashboard("error", `⚠️ Cleanup error: ${e.message}`);
      }
    }

    logToDashboard("warn", "🔁 Reconnecting in 5 seconds...");
    await delay(5000);
  }
};

// ------------------ Start Script ------------------
runClient();
