const { OPCUAClient, AttributeIds, DataType } = require("node-opcua");
const axios = require("axios");
const ExcelJS = require("exceljs");
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

// ------------------ CONFIG ------------------
const API_URL = "https://mismainapp.tataautocomp.com:3242";

// ------------------ EXPRESS + SOCKET ------------------
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" }
});

server.listen(4001, () => {
  console.log("🚀 Socket Server running at http://localhost:4001");
});

// ------------------ SOCKET CONNECTION ------------------
io.on("connection", (socket) => {
  console.log("🌐 Frontend connected");

  socket.on("disconnect", () => {
    console.log("❌ Frontend disconnected");
  });
});

// ------------------ In-Memory Storage ------------------
const logs = [];
let latestOpcData = {};
let packqrcodeLine3 = null;

// ------------------ LOGGER ------------------
const logToDashboard = (type, message) => {
  const log = {
    type,
    message,
    time: new Date().toISOString()
  };

  console.log(`[${type.toUpperCase()}] ${message}`);

  logs.push(log);
  if (logs.length > 200) logs.shift();

  // ✅ Send to frontend
  io.emit("log", log);
};

// ------------------ Delay ------------------
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ------------------ Excel Config ------------------
const readOpcConfigFromExcel = async () => {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile("./opc_config.xlsx");

  const row = workbook.worksheets[0].getRow(2);
  const opcIp = row.getCell(1).value;
  const opcPort = row.getCell(2).value;

  if (!opcIp || !opcPort) {
    throw new Error("OPC IP or Port missing in Excel");
  }

  return `opc.tcp://${opcIp}:${opcPort}`;
};

// ------------------ OPC CONFIG ------------------
let opcuaConfig = {
  endpointUrl: "",
  module_barcode: "ns=4;i=6",
  modulebarcode_validation_start: "ns=4;i=7",
  modulebarcode_process_done: "ns=4;i=8",
  modulebarcode_result: "ns=4;i=9",
  mis_ready: "ns=4;i=10"
};

// ------------------ OPC HELPERS ------------------
const readTag = async (session, nodeId) => {
  const result = await session.read({
    nodeId,
    attributeId: AttributeIds.Value
  });
  return result.value.value;
};

const writeTag = async (session, nodeId, dataType, value) => {
  await session.write({
    nodeId,
    attributeId: AttributeIds.Value,
    value: { value: { dataType, value } }
  });
};

// ================== MERGED LOGIC ==================

// ✅ validate_modulebarcode
const validateModuleBarcode = async (modulebarcode) => {
  if (!modulebarcode || typeof modulebarcode !== "string") {
    return { valid: false };
  }

  const url = `${API_URL}/fetch_nomenclature/${modulebarcode}`;
  logToDashboard("info", `Calling URL: ${url}`);

  try {
    const response = await axios.get(url);

    if (response.status !== 200) {
      return { valid: false };
    }

    const data = response.data;

    if (!Array.isArray(data) || data.length === 0) {
      return { valid: false };
    }

    const first_row = data[0];

    if (first_row.api_status === "Data Not Found") {
      return { valid: false };
    }

    packqrcodeLine3 = modulebarcode;

    return { valid: true };

  } catch (err) {
    logToDashboard("error", `Validation error: ${err.message}`);
    return { valid: false };
  }
};

// ✅ store_wel_insp_result
const storeWelderInspectionResult = async (module_barcode, modulebarcode_result) => {
  if (!module_barcode || !modulebarcode_result) {
    throw new Error("module_barcode and modulebarcode_result are required");
  }

  try {
    const payload = {
      station_id: 3036,
      line_id: 3,
      customer_qrcode: packqrcodeLine3,
      station_status: "OK",
      checklist_name: "NA",
      substation_id: "NA"
    };

    await axios.post(`${API_URL}/station_status/filter`, payload);

    logToDashboard("success", "Line 3: Station status pushed successfully");
    return { success: true };

  } catch (err) {
    logToDashboard("error", `Store error: ${err.message}`);
    return { success: false };
  }
};

// ================== OPC RUNNER ==================
const runClient = async () => {
  try {
    opcuaConfig.endpointUrl = await readOpcConfigFromExcel();

    logToDashboard(
      "success",
      `📘 OPC Endpoint Loaded: ${opcuaConfig.endpointUrl}`
    );
  } catch (err) {
    logToDashboard("error", `❌ Excel Config Error: ${err.message}`);
    process.exit(1);
  }

  while (true) {
    const client = OPCUAClient.create({
      endpointMustExist: false,
      keepSessionAlive: true,
      connectionStrategy: {
        initialDelay: 1000,
        maxRetry: 10
      },
      requestedSessionTimeout: 60000
    });

    let session = null;

    try {
      await client.connect(opcuaConfig.endpointUrl);
      logToDashboard("success", "✅ Connected to OPC UA server");

      session = await client.createSession();

      while (true) {
        const currentTagValues = {
          module_barcode: await readTag(session, opcuaConfig.module_barcode),
          modulebarcode_validation_start: await readTag(session, opcuaConfig.modulebarcode_validation_start),
          modulebarcode_process_done: await readTag(session, opcuaConfig.modulebarcode_process_done),
          modulebarcode_result: await readTag(session, opcuaConfig.modulebarcode_result),
          mis_ready: await readTag(session, opcuaConfig.mis_ready)
        };

        latestOpcData = currentTagValues;

        // ✅ Send OPC data live
        io.emit("opcData", currentTagValues);

        logToDashboard("info", `📋 OPC UA Values: ${JSON.stringify(currentTagValues)}`);

        // Always ready
        await writeTag(session, opcuaConfig.mis_ready, DataType.Boolean, true);

        const {
          module_barcode,
          modulebarcode_validation_start,
          modulebarcode_process_done,
          modulebarcode_result
        } = currentTagValues;

        // 🔹 VALIDATION (same logic)
        if (modulebarcode_validation_start === 1) {
          try {
            logToDashboard("info", `📤 Sending Barcode: ${module_barcode}`);

            const res = await validateModuleBarcode(module_barcode);

            await writeTag(
              session,
              opcuaConfig.modulebarcode_validation_start,
              DataType.Int16,
              res.valid ? 2 : 3
            );

            logToDashboard(
              res.valid ? "success" : "warn",
              res.valid ? "✅ Barcode valid" : "❌ Barcode not found"
            );

          } catch (err) {
            logToDashboard("error", `🚨 Validation error: ${err.message}`);
          }
        }

        // 🔹 RESULT (same logic)
        if (modulebarcode_process_done === 1) {
          try {
            logToDashboard("info", "📤 Sending result to API");

            await storeWelderInspectionResult(
              module_barcode,
              modulebarcode_result
            );

            await writeTag(
              session,
              opcuaConfig.modulebarcode_process_done,
              DataType.Int16,
              2
            );

            logToDashboard("success", "✅ Result stored");

          } catch (err) {
            logToDashboard("error", `🚨 Store failed: ${err.message}`);
          }
        }

        await delay(5000);
      }

    } catch (err) {
      logToDashboard("error", `❌ OPC UA Error: ${err.message}`);
    } finally {
      try {
        if (session) await session.close();
        await client.disconnect();
      } catch (e) {
        logToDashboard("error", `⚠️ Cleanup error: ${e.message}`);
      }
    }

    logToDashboard("warn", "🔁 Reconnecting in 5 seconds...");
    await delay(5000);
  }
};

// ------------------ START ------------------
runClient();