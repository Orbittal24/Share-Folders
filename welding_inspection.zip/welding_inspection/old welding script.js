const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const { OPCUAClient, AttributeIds, DataType } = require("node-opcua");
const axios = require("axios");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static("public"));

const logToDashboard = (type, message) => {
  console.log(message);
  io.emit("log", { type, message });
};

const opcuaConfig = {
  endpointUrl: "opc.tcp://192.168.1.100:4840",
  module_barcode: "ns=4;i=6",
  modulebarcode_validation_start: "ns=4;i=7",
  modulebarcode_process_done: "ns=4;i=8",
  modulebarcode_result: "ns=4;i=9",
  mis_ready: "ns=4;i=10"

};

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const readTag = async (session, nodeId) => {
  const result = await session.read({ nodeId, attributeId: AttributeIds.Value });
  return result.value.value;
};

const writeTag = async (session, nodeId, dataType, value) => {
  await session.write({
    nodeId,
    attributeId: AttributeIds.Value,
    value: {
      value: {
        dataType,
        value
      }
    }
  });
};

// new code with handled
const runClient = async () => {
  while (true) {
    const client = OPCUAClient.create({
      endpointMustExist: false,
      keepSessionAlive: true,
      connectionStrategy: {
        initialDelay: 1000,
        maxRetry: 10
      },
      requestedSessionTimeout: 60000
    });

    let session = null; // keep session reference

    try {
      await client.connect(opcuaConfig.endpointUrl);
      logToDashboard("success", "✅ Connected to OPC UA server.");

      session = await client.createSession();
      logToDashboard("success", " OPC UA session started.");

      session.on("keepalive", () => logToDashboard("success", "🔄 Session keepalive"));
      session.on("session_closed", () => logToDashboard("warn", "⚠️ Session closed"));

      // main polling loop
      while (true) {
        const currentTagValues = {
          module_barcode: await readTag(session, opcuaConfig.module_barcode),
          modulebarcode_validation_start: await readTag(session, opcuaConfig.modulebarcode_validation_start),
          modulebarcode_process_done: await readTag(session, opcuaConfig.modulebarcode_process_done),
          modulebarcode_result: await readTag(session, opcuaConfig.modulebarcode_result),
          mis_ready: await readTag(session, opcuaConfig.mis_ready)
        };

        logToDashboard("success", `📋 Current OPC UA Tag Values: ${JSON.stringify(currentTagValues)}`);

        // ✅ Always write mis_ready = true
        await writeTag(session, opcuaConfig.mis_ready, DataType.Boolean, true);
        logToDashboard("info", "🔧 mis_ready set to TRUE");

        const {
          module_barcode,
          modulebarcode_validation_start,
          modulebarcode_process_done,
          modulebarcode_result
        } = currentTagValues;

        // Step 1: Validate QR
        if (modulebarcode_validation_start === 1) {
          try {
            const res = await axios.post("https://mismainapp.tataautocomp.com:3242/validate_modulebarcode", {
              modulebarcode: module_barcode
            });

            if (res.data.valid) {
              await writeTag(session, opcuaConfig.modulebarcode_validation_start, DataType.Int16, 2);
              logToDashboard("success", "✅ QR valid. Sent modulebarcode_validation_start = 2");
            } else {
              await writeTag(session, opcuaConfig.modulebarcode_validation_start, DataType.Int16, 3);
              logToDashboard("warn", "❌ QR not found. Sent modulebarcode_validation_start = 3");
            }
          } catch (error) {
            logToDashboard("error", `🚨 Module Barcode Validation error: ${error.message}`);
          }
        }

        // Step 2: Store result if cycle is done
        if (modulebarcode_process_done === 1) {
          try {
            await axios.post("https://mismainapp.tataautocomp.com:3242/store_wel_insp_result", {
              modulebarcode_result: modulebarcode_result,
              module_barcode: module_barcode
            });

            await writeTag(session, opcuaConfig.modulebarcode_process_done, DataType.Int16, 2);
            logToDashboard("success", "✅ Result stored. Updated modulebarcode_process_done = 2");
          } catch (err) {
            logToDashboard("error", `🚨 Result store failed: ${err.message}`);
          }
        }

        await delay(5000); // poll every 5s
      }
    } catch (err) {
      logToDashboard("error", `❌ OPC UA Error: ${err.message}`);
    } finally {
      // ✅ Always cleanup before reconnect
      try {
        if (session) {
          await session.close();
          logToDashboard("warn", "🔒 Session closed.");
        }
      } catch (closeErr) {
        logToDashboard("error", `⚠️ Error closing session: ${closeErr.message}`);
      }

      try {
        await client.disconnect();
        logToDashboard("warn", "🔌 Disconnected from OPC UA server.");
      } catch (discErr) {
        logToDashboard("error", `⚠️ Error disconnecting client: ${discErr.message}`);
      }
    }

    // wait before retrying
    logToDashboard("warn", "🔁 Reconnecting in 5 seconds...");
    await delay(5000);
  }
};


server.listen(4000, () => {
  console.log(" Server listening on http://localhost:4000");
  runClient();
});
