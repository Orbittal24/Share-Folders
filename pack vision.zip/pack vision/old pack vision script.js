const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const { OPCUAClient, AttributeIds, DataType } = require("node-opcua");
const axios = require("axios");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static("public"));

const logToDashboard = (type, message) => {
  console.log(message);
  io.emit("log", { type, message });
};

const opcuaConfig = {
  endpointUrl: "opc.tcp://192.168.0.1:4840",
  pack_qr_code: "ns=4;i=6",
  pack_validation_start: "ns=4;i=7",
  pack_cycle_status: "ns=4;i=8",
  pack_result: "ns=4;i=9",
  pack_result_done: "ns=4;i=10"
};

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const readTag = async (session, nodeId) => {
  const result = await session.read({ nodeId, attributeId: AttributeIds.Value });
  return result.value.value;
};

const writeTag = async (session, nodeId, dataType, value) => {
  await session.write({
    nodeId,
    attributeId: AttributeIds.Value,
    value: {
      value: {
        dataType,
        value
      }
    }
  });
};

const runClient = async () => {
  while (true) {
    const client = OPCUAClient.create({
      endpointMustExist: false,
      keepSessionAlive: true,
      connectionStrategy: {
        initialDelay: 1000,
        maxRetry: 10
      },
      requestedSessionTimeout: 60000
    });

    try {
      await client.connect(opcuaConfig.endpointUrl);
      logToDashboard("success", "✅ Connected to OPC UA server.");

      const session = await client.createSession();
      logToDashboard("success", "✅ OPC UA session started.");

      session.on("keepalive", () => logToDashboard("success", "🔄 Session keepalive"));
      session.on("session_closed", () => logToDashboard("warn", "⚠️ Session closed"));

      while (true) {
        // 🔁 Read all tag values
        const currentTagValues = {
          pack_qr_code: await readTag(session, opcuaConfig.pack_qr_code),
          pack_validation_start: await readTag(session, opcuaConfig.pack_validation_start),
          pack_cycle_status: await readTag(session, opcuaConfig.pack_cycle_status),
          pack_result: await readTag(session, opcuaConfig.pack_result),
          pack_result_done: await readTag(session, opcuaConfig.pack_result_done)
        };

        logToDashboard("success", `📋 Current OPC UA Tag Values: ${JSON.stringify(currentTagValues)}`);

        const {
          pack_qr_code,
          pack_validation_start,
          pack_cycle_status,
          pack_result,
          pack_result_done
        } = currentTagValues;

        // ✅ Step 1: Validate QR
        if (pack_validation_start === 1) {
          console.log("going for validation")
          try {
            const res = await axios.post("http://10.9.4.28:7007/pack_vision_3_4/validate_qr", {
              qr: pack_qr_code
            });

            if (res.data.valid) {
              console.log("data receved...",res.data.valid)
              await writeTag(session, opcuaConfig.pack_validation_start, DataType.Int16, 2);
              logToDashboard("success", "✅ QR valid. Sent pack_validation_start = 2");
            } else {
              await writeTag(session, opcuaConfig.pack_validation_start, DataType.Int16, 3);
              logToDashboard("warn", "❌ QR not found. Sent pack_validation_start = 3");
            }
          } catch (error) {
            logToDashboard("error", `🚨 QR Validation error: ${error.message}`);
          }
        }

        // ✅ Step 2: Store result if cycle is done
        if (pack_result_done === 1) {
          try {
            await axios.post("http://10.9.4.28:7007/pack_vision_3_4/store_result", {
              status: pack_cycle_status,
              result: pack_result,
              pack_qr_code: pack_qr_code
            });

            await writeTag(session, opcuaConfig.pack_result_done, DataType.Int16, 2);
            logToDashboard("success", "✅ Result stored. Updated pack_result_done = 2");
          } catch (err) {
            logToDashboard("error", `🚨 Result store failed: ${err.message}`);
          }
        }

        await delay(5000); // ⏱ Poll every 5 seconds
      }
    } catch (err) {
      logToDashboard("error", `❌ OPC UA Error: ${err.message}`);
    }

    logToDashboard("warn", "🔁 Reconnecting in 5 seconds...");
    await delay(5000);
  }
};

server.listen(4000, () => {
  console.log("🚀 Server listening on http://10.9.5.204:4000");
  runClient();
});
