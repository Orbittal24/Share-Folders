const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const { OPCUAClient, AttributeIds, DataType } = require("node-opcua");
const axios = require("axios");
const ExcelJS = require("exceljs");

// ------------------ CONFIG ------------------
const API_URL = "https://mismainapp.tataautocomp.com:3242";

// ------------------ SERVER SETUP ------------------
const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" }
});

server.listen(4001, () => {
  console.log("🚀 Socket.IO Server running on port 4001");
});

// ------------------ SOCKET ------------------
io.on("connection", (socket) => {
  console.log("🌐 Frontend connected");

  socket.on("disconnect", () => {
    console.log("❌ Frontend disconnected");
  });
});

// ------------------ LOGGER ------------------
const logToDashboard = (type, message) => {
  console.log(`[${type.toUpperCase()}] ${message}`);

  io.emit("log", {
    type,
    message,
    time: new Date().toLocaleTimeString()
  });
};

// ------------------ DELAY ------------------
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

// ------------------ READ EXCEL ------------------
const readOpcConfigFromExcel = async () => {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile("./opc_config.xlsx");

  const row = workbook.worksheets[0].getRow(2);
  return `opc.tcp://${row.getCell(1).value}:${row.getCell(2).value}`;
};

// ------------------ OPC CONFIG ------------------
let opcuaConfig = {
  endpointUrl: "",
  pack_qr_code: "ns=4;i=6",
  pack_validation_start: "ns=4;i=7",
  pack_cycle_status: "ns=4;i=8",
  pack_result: "ns=4;i=9",
  pack_result_done: "ns=4;i=10"
};

// ------------------ OPC READ ------------------
const readTag = async (session, nodeId) => {
  const res = await session.read({
    nodeId,
    attributeId: AttributeIds.Value
  });
  return res.value.value;
};

// ------------------ OPC WRITE ------------------
const writeTag = async (session, nodeId, dataType, value) => {
  await session.write({
    nodeId,
    attributeId: AttributeIds.Value,
    value: { value: { dataType, value } }
  });
};

// ------------------ VALIDATE QR ------------------
const validateQR = async (qr) => {
  if (!qr || typeof qr !== "string") {
    return { valid: false };
  }

  const url = `${API_URL}/fetch_nomenclature/${qr}`;
  logToDashboard("info", `Calling: ${url}`);

  try {
    const response = await axios.get(url);

    if (response.status !== 200) {
      return { valid: false };
    }

    const data = response.data;

    if (!Array.isArray(data) || data.length === 0) {
      return { valid: false };
    }

    const firstRow = data[0];

    if (firstRow.api_status === "Data Not Found") {
      return { valid: false };
    }

    return { valid: true };

  } catch (err) {
    logToDashboard("error", `Validation Error: ${err.message}`);
    return { valid: false };
  }
};

// ------------------ STORE RESULT ------------------
const storeResult = async (status, result, pack_qr_code) => {
  try {
    const payload = {
      station_id: 3035,
      line_id: 1,
      customer_qrcode: pack_qr_code,
      station_status: "OK",
      checklist_name: "NA",
      substation_id: "NA"
    };

    await axios.post(`${API_URL}/station_status/filter`, payload);

    return { success: true };

  } catch (err) {
    logToDashboard("error", `Store Error: ${err.message}`);
    return { success: false };
  }
};

// ------------------ MAIN OPC CLIENT ------------------
const runClient = async () => {
  opcuaConfig.endpointUrl = await readOpcConfigFromExcel();

  let lastValidationState = 0;
  let lastResultState = 0;

  while (true) {
    const client = OPCUAClient.create({ endpointMustExist: false });
    let session;

    try {
      await client.connect(opcuaConfig.endpointUrl);
      logToDashboard("success", "Connected to OPC UA");

      session = await client.createSession();

      while (true) {
        const values = {
          pack_qr_code: await readTag(session, opcuaConfig.pack_qr_code),
          pack_validation_start: await readTag(session, opcuaConfig.pack_validation_start),
          pack_cycle_status: await readTag(session, opcuaConfig.pack_cycle_status),
          pack_result: await readTag(session, opcuaConfig.pack_result),
          pack_result_done: await readTag(session, opcuaConfig.pack_result_done)
        };

        logToDashboard("info", "📡 OPC Values Updated");

        // ---------------- VALIDATION ----------------
        if (values.pack_validation_start === 1 && lastValidationState !== 1) {
          lastValidationState = 1;

          logToDashboard("warn", "Validation triggered");

          const res = await validateQR(values.pack_qr_code);

          await writeTag(
            session,
            opcuaConfig.pack_validation_start,
            DataType.Int16,
            res.valid ? 2 : 3
          );

          logToDashboard(
            res.valid ? "success" : "error",
            res.valid ? "QR Valid ✅" : "QR Invalid ❌"
          );
        }

        if (values.pack_validation_start === 0) {
          lastValidationState = 0;
        }

        // ---------------- RESULT ----------------
        if (values.pack_result_done === 1 && lastResultState !== 1) {
          lastResultState = 1;

          const res = await storeResult(
            values.pack_cycle_status,
            values.pack_result,
            values.pack_qr_code
          );

          if (res.success) {
            await writeTag(
              session,
              opcuaConfig.pack_result_done,
              DataType.Int16,
              2
            );

            logToDashboard("success", "Final result stored ✅");
          } else {
            logToDashboard("error", "Result storing failed ❌");
          }
        }

        if (values.pack_result_done === 0) {
          lastResultState = 0;
        }

        await delay(3000);
      }

    } catch (err) {
      logToDashboard("error", err.message);
    } finally {
      if (session) await session.close();
      await client.disconnect();
      logToDashboard("warn", "Disconnected. Retrying...");
    }

    await delay(5000);
  }
};

// ------------------ START ------------------
runClient();