const sql = require('mssql');
const dayjs = require('dayjs');
const EventEmitter = require('events');
const axios = require('axios');

EventEmitter.defaultMaxListeners = 20;

// Mappings for decoding QR codes
const yearMap = {
  B: 21, C: 22, D: 23, E: 24, F: 25, G: 26, H: 27, J: 28, K: 29, L: 30,
  M: 31, N: 32, P: 33, R: 34, S: 35, T: 36, V: 37, W: 38, X: 39, Y: 40,
  1: 41, 2: 42, 3: 43, 4: 44, 5: 45, 6: 46, 7: 47, 8: 48, 9: 49, A: 50
};

const monthMap = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12 };

const dayMap = {
  1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12,
  D: 13, E: 14, F: 15, G: 16, H: 17, J: 18, K: 19, L: 20, M: 21, N: 22,
  P: 23, R: 24, S: 25, T: 26, V: 27, W: 28, X: 29, Y: 30, 0: 31
};

const lineMap = {
  1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, G: 16, H:17
};

// Database configurations
const configs = {
  pool1: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool2: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability_master',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool3: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability_station_status',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool4: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability_master_module_register',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool5: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability_master_pack_register',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool6: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'cell_scanning_master',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  },
  pool7: {
    user: 'user_mis',
    password: 'admin',
    server: '10.9.4.28\\MSSQLSERVER',
    database: 'taco_treceability_station_status_history',
    options: {
      encrypt: true,
      trustServerCertificate: true,
      connectTimeout: 30000,
      requestTimeout: 60000
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    }
  }
};

// ============================================================================
// GLOBAL TRACKING OBJECTS
// ============================================================================
const processedModules = new Map(); // Track module QR codes processed in current batch
const processedPacks = new Map();   // Track pack numbers processed in current batch
const processedInterlockModules = new Map(); // Track modules processed for station interlock API

// Connection management
const connectionPools = {};

async function getConnection(poolName) {
  if (connectionPools[poolName] && connectionPools[poolName].connected) {
    return connectionPools[poolName];
  }

  let retries = 1;
  let lastError = null;
 
  while (retries-- > 0) {
    try {
      const pool = new sql.ConnectionPool(configs[poolName]);
      await pool.connect();
      console.log(`${poolName} connected successfully`);
     
      connectionPools[poolName] = pool;
     
      pool.on('error', err => {
        console.error(`Pool ${poolName} error:`, err.message);
        delete connectionPools[poolName];
      });
     
      return pool;
    } catch (err) {
      lastError = err;
      console.error(`Attempt ${3-retries} failed for ${poolName}:`, err.message);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
 
  console.error(`All connection attempts failed for ${poolName}`);
  throw lastError;
}

async function withConnection(poolName, callback) {
  let pool;
  try {
    pool = await getConnection(poolName);
    return await callback(pool);
  } catch (err) {
    console.error(`Error in ${poolName} operation:`, err.message);
   
    if (err.code === 'ETIMEOUT' || err.code === 'ESOCKET') {
      console.error('Network connectivity issue detected');
      if (pool) {
        delete connectionPools[poolName];
      }
    }
   
    throw err;
  } finally {
    if (pool && (pool.connected === false || pool._connected === false)) {
      try {
        await pool.close();
        delete connectionPools[poolName];
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr.message);
      }
    }
  }
}

// ============================================================================
// API CONFIGURATION
// ============================================================================
const API_CONFIG = {
  BASE_URL: 'https://mismainapp.tataautocomp.com:3241',
  ENDPOINTS: {
    INSERT_COMBINED_STATUS: '/insert_combined_ModulePack_status/',
    STATION_INTERLOCK: '/station_status/filter'
  },
  TIMEOUT: 30000,
  RETRY_ATTEMPTS: 1,
  RETRY_DELAY: 5000
};

// ============================================================================
// API SERVICE FUNCTIONS
// ============================================================================
async function callAPI(endpoint, data) {
  const url = `${API_CONFIG.BASE_URL}${endpoint}`;
  
  try {
    console.log(`[API] Calling ${url}`);
    
    const response = await axios({
      method: 'post',
      url: url,
      data: data,
      timeout: API_CONFIG.TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    console.log(`[API] Success - Status: ${response.status}`);
    return { success: true, data: response.data, status: response.status };
  } catch (err) {
    console.error(`[API] Error: ${err.message}`);
    return { success: false, error: err.message };
  }
}

// ============================================================================
// CHECK IF MODULE ALREADY HAS API ENTRY
// ============================================================================
async function checkModuleHasAPIEntry(packID, moduleID, packNo) {
  const moduleKey = `${packID}_${moduleID}_${packNo}`;
  if (processedModules.has(moduleKey)) {
    console.log(`[API] Module ${moduleKey} already processed in this batch`);
    return true;
  }
  
  processedModules.set(moduleKey, true);
  return false;
}

// ============================================================================
// CHECK IF PACK ALREADY HAS API ENTRY
// ============================================================================
async function checkPackHasAPIEntry(packID, packNo) {
  const packKey = `${packID}_${packNo}`;
  if (processedPacks.has(packKey)) {
    console.log(`[API] Pack ${packKey} already processed in this batch`);
    return true;
  }
  
  processedPacks.set(packKey, true);
  return false;
}

// ============================================================================
// CHECK IF MODULE ALREADY SENT TO STATION INTERLOCK API
// ============================================================================
async function checkModuleHasInterlockEntry(module_barcode) {
  const moduleKey = `interlock_${module_barcode}`;
  if (processedInterlockModules.has(moduleKey)) {
    console.log(`[INTERLOCK API] Module ${module_barcode} already sent to station interlock in this batch`);
    return true;
  }
  
  processedInterlockModules.set(moduleKey, true);
  return false;
}

// ============================================================================
// INSERT MODULE STATUS VIA API
// ============================================================================
async function insertModuleStatusViaAPI(packID, moduleID, packNo, packDate, lineID, operatorData = {}) {
  try {
    const alreadyProcessed = await checkModuleHasAPIEntry(packID, moduleID, packNo);
    if (alreadyProcessed) {
      return { success: true, skipped: true, message: 'Already processed in this batch' };
    }
    
    let packName = '';
    try {
      packName = await getPackName(packID);
    } catch (err) {
      console.warn(`[API] Could not fetch pack name for ID ${packID}:`, err.message);
      packName = `Pack_${packID}`;
    }

    const apiData = {
      pack_number: packNo,
      packid: packID.toString(),
      pack_name: packName,
      line_id: lineID.toString(),
      pack_creation_date: `${packDate} 00:00:00`
    };

    if (operatorData.operator_id) apiData.operator_id = operatorData.operator_id;
    if (operatorData.operator_name) apiData.operator_name = operatorData.operator_name;
    if (operatorData.updated_by) apiData.updated_by = operatorData.updated_by;

    console.log(`[API] Inserting module status for pack ${packNo}, module ${moduleID}`);
    
    const result = await callAPI(API_CONFIG.ENDPOINTS.INSERT_COMBINED_STATUS, apiData);
    
    return result;
  } catch (err) {
    console.error(`[API] Error in insertModuleStatusViaAPI:`, err.message);
    return { success: false, error: err.message };
  }
}

// ============================================================================
// INSERT PACK STATUS VIA API
// ============================================================================
async function insertPackStatusViaAPI(packID, packNo, packDate, lineID, operatorData = {}) {
  try {
    const alreadyProcessed = await checkPackHasAPIEntry(packID, packNo);
    if (alreadyProcessed) {
      return { success: true, skipped: true, message: 'Already processed in this batch' };
    }
    
    let packName = '';
    try {
      packName = await getPackName(packID);
    } catch (err) {
      console.warn(`[API] Could not fetch pack name for ID ${packID}:`, err.message);
      packName = `Pack_${packID}`;
    }

    const apiData = {
      pack_number: packNo,
      packid: packID.toString(),
      pack_name: packName,
      line_id: lineID.toString(),
      pack_creation_date: `${packDate} 00:00:00`,
      update_type: 'pack_status_insert'
    };

    if (operatorData.operator_id) apiData.operator_id = operatorData.operator_id;
    if (operatorData.operator_name) apiData.operator_name = operatorData.operator_name;
    if (operatorData.updated_by) apiData.updated_by = operatorData.updated_by;

    console.log(`[API] Inserting pack status for pack ${packNo}`);
    
    const result = await callAPI(API_CONFIG.ENDPOINTS.INSERT_COMBINED_STATUS, apiData);
    
    return result;
  } catch (err) {
    console.error(`[API] Error in insertPackStatusViaAPI:`, err.message);
    return { success: false, error: err.message };
  }
}

// ============================================================================
// SEND MODULE TO STATION INTERLOCK API
// ============================================================================
async function sendToStationInterlockAPI(module_barcode, lineID, rowData = {}) {
  try {
    // Check if module already sent to station interlock API
    const alreadyProcessed = await checkModuleHasInterlockEntry(module_barcode);
    if (alreadyProcessed) {
      return { success: true, skipped: true, message: 'Already sent to station interlock in this batch' };
    }

    const stationId = 28; // Fixed station ID as per requirements
    const lineId = 1; // Use the calculated line ID

    const apiData = {
      station_id: stationId,
      line_id: lineId,
      customer_qrcode: module_barcode,
      station_status:"OK",
      checklist_name:"NA",
      substation_id:"NA"
    };



    console.log(`[INTERLOCK API] Sending module ${module_barcode} to station interlock (Station: ${stationId}, Line: ${lineId})`);
    
    const result = await callAPI(API_CONFIG.ENDPOINTS.STATION_INTERLOCK, apiData);
    
    return result;
  } catch (err) {
    console.error(`[INTERLOCK API] Error sending module ${module_barcode} to station interlock:`, err.message);
    return { success: false, error: err.message };
  }
}

// ============================================================================
// HELPER FUNCTION TO GET PACK NAME
// ============================================================================
async function getPackName(packID) {
  return withConnection('pool2', async (pool2) => {
    const result = await pool2.request()
      .input('packID', sql.Int, packID)
      .query(`SELECT Pack_Name FROM [taco_treceability_master].[taco_treceability].[master_pack] WHERE Pack_ID = @packID`);
    
    if (result.recordset.length > 0) {
      return result.recordset[0].Pack_Name;
    }
    
    throw new Error(`Pack ID ${packID} not found`);
  });
}

// ============================================================================
// SAFE INSERT FUNCTION
// ============================================================================
async function safeInsert(pool, schema, tableName, data) {
  try {
    const columns = Object.keys(data).map(key => `[${key}]`).join(', ');
    const values = Object.keys(data).map(key => `@${key}`).join(', ');
    
    const request = pool.request();
    Object.keys(data).forEach(key => {
      request.input(key, data[key]);
    });
    
    await request.query(`
      INSERT INTO [${schema}].[${tableName}]
      (${columns})
      VALUES (${values})
    `);
    
    return { success: true };
  } catch (err) {
    if (err.message.includes('Invalid column name')) {
      console.warn(`⚠️ Column missing in ${tableName}, attempting partial insert...`);
      
      try {
        const columnResult = await pool.request()
          .query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '${schema}' 
            AND TABLE_NAME = '${tableName}'
          `);
        
        const existingColumns = columnResult.recordset.map(row => row.COLUMN_NAME);
        
        const filteredData = {};
        Object.keys(data).forEach(key => {
          if (existingColumns.includes(key)) {
            filteredData[key] = data[key];
          } else {
            console.warn(`⚠️ Column '${key}' not found in ${tableName}, skipping...`);
          }
        });
        
        if (Object.keys(filteredData).length > 0) {
          const columns = Object.keys(filteredData).map(key => `[${key}]`).join(', ');
          const values = Object.keys(filteredData).map(key => `@${key}`).join(', ');
          
          const request = pool.request();
          Object.keys(filteredData).forEach(key => {
            request.input(key, filteredData[key]);
          });
          
          await request.query(`
            INSERT INTO [${schema}].[${tableName}]
            (${columns})
            VALUES (${values})
          `);
          
          return { success: true, partial: true };
        } else {
          console.error(`❌ No valid columns found for ${tableName}`);
          return { success: false, error: err.message };
        }
      } catch (innerErr) {
        console.error(`❌ Error in partial insert for ${tableName}:`, innerErr.message);
        return { success: false, error: innerErr.message };
      }
    } else {
      console.error(`❌ Error inserting into ${tableName}:`, err.message);
      return { success: false, error: err.message };
    }
  }
}

// ============================================================================
// SAFE UPDATE OPERATOR FUNCTION
// ============================================================================
async function safeUpdateOperator(pool, schema, tableName, idField, idValue, operatorData) {
  try {
    const columnResult = await pool.request()
      .query(`
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = '${schema}' 
        AND TABLE_NAME = '${tableName}'
        AND COLUMN_NAME IN ('operator_id', 'operator_name', 'updated_by', 'operator')
      `);
    
    const existingOperatorColumns = columnResult.recordset.map(row => row.COLUMN_NAME);
    
    if (existingOperatorColumns.length > 0) {
      const setClauses = [];
      const request = pool.request();
      
      existingOperatorColumns.forEach(col => {
        if (operatorData[col]) {
          setClauses.push(`[${col}] = @${col}`);
          request.input(col, operatorData[col]);
        }
      });
      
      if (setClauses.length > 0) {
        request.input('idValue', idValue);
        
        await request.query(`
          UPDATE [${schema}].[${tableName}]
          SET ${setClauses.join(', ')}
          WHERE [${idField}] = @idValue
        `);
        
        console.log(`✅ Updated ${setClauses.length} operator fields in ${tableName}`);
      }
    }
  } catch (err) {
    console.warn(`⚠️ Could not update operator fields in ${tableName}:`, err.message);
  }
}

// ============================================================================
// EXTRACT OPERATOR DATA
// ============================================================================
function extractOperatorData(row) {
  const operatorData = {};
  
  if (row.operator_id) operatorData.operator_id = row.operator_id;
  if (row.operator_name) operatorData.operator_name = row.operator_name;
  if (row.updated_by) operatorData.updated_by = row.updated_by;
  if (row.operator) operatorData.operator = row.operator;
  
  return operatorData;
}

// ============================================================================
// MAIN PROCESSING FUNCTIONS
// ============================================================================
async function processRecords() {
  try {
    console.log('Fetching records to process...');
    const records = await fetchRecordsToProcess();
   
    if (records.length === 0) {
      console.log('No records found to process');
      return;
    }

    // Clear tracking maps for new batch
    processedModules.clear();
    processedPacks.clear();
    processedInterlockModules.clear();
    
    const processingResults = await processAllRecords(records);
    
    await cleanupProcessedRecords(processingResults);
   
    console.log(`Processing complete. ${processingResults.successCount} succeeded, ${processingResults.errorCount} failed`);
  } catch (err) {
    console.error('Fatal error in processRecords:', err.message);
  }
}

async function fetchRecordsToProcess() {
  return withConnection('pool1', async (pool) => {
    const result = await pool.request().query(`
      SELECT sr_no, line, battery_pack_name, final_qr_code, moduleNumber, module_barcode, today_date
      FROM taco_treceability.master_compress_data
      ORDER BY sr_no
    `);
    return result.recordset;
  });
}

async function processAllRecords(records) {
  const schema_table = 'taco_treceability';
  const schema_table2 = 'dbo';
  const createdTables = new Set();
  const result = {
    processedSrNos: [],
    successCount: 0,
    errorCount: 0,
    failedInserts: []
  };

  for (const [index, row] of records.entries()) {
    try {
      console.log(`Processing record ${index + 1}/${records.length} (sr_no: ${row.sr_no})`);
     
      if (!validateRecord(row)) {
        result.errorCount++;
        continue;
      }

      const { year, month, day } = decodeDateFromBarcode(row.module_barcode);
      if (!year || !month || !day) {
        console.warn(`⚠️ Skipping sr_no ${row.sr_no} due to invalid date codes`);
        result.errorCount++;
        continue;
      }

      const dateFormats = calculateDateFormats(year, month, day);
      const tableNames = generateTableNames(dateFormats);

      await ensureTablesExist(tableNames, createdTables, schema_table, schema_table2);

      const last6Digits = extractLast6Digits(row.final_qr_code);
      if (!last6Digits) {
        result.errorCount++;
        continue;
      }

      // Check if record already exists in target table
      const exists = await recordExists(row.module_barcode, tableNames.targetTable, schema_table);
      if (exists) {
        console.log(`ℹ️ Module ${row.module_barcode} already exists in ${tableNames.targetTable}, attempting update...`);
        
        const updateSuccess = await updateExistingRecord(row, dateFormats, tableNames, last6Digits, schema_table, schema_table2);
        if (updateSuccess) {
          result.successCount++;
          result.processedSrNos.push(row.sr_no);
          console.log(`✅ Successfully updated sr_no ${row.sr_no}`);
        } else {
          result.errorCount++;
          console.log(`❌ Failed to update sr_no ${row.sr_no}`);
        }
        continue;
      }

      // Process new record
      const insertResults = await processPackAndModuleData(
        row,
        dateFormats,
        tableNames,
        last6Digits,
        schema_table,
        schema_table2
      );

      const allSuccessful = insertResults.every(r => r.success || r.skipped);
      
      if (allSuccessful) {
        result.successCount++;
        result.processedSrNos.push(row.sr_no);
        console.log(`✅ Successfully processed sr_no ${row.sr_no}`);
      } else {
        result.errorCount++;
        result.failedInserts.push({
          sr_no: row.sr_no,
          errors: insertResults.filter(r => !r.success && !r.skipped).map(r => r.error)
        });
        console.log(`❌ Failed to insert sr_no ${row.sr_no} into all tables`);
      }
    } catch (err) {
      console.error(`❌ Error processing sr_no ${row.sr_no}:`, err.message);
      result.errorCount++;
    }
  }

  return result;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
function validateRecord(row) {
  if (!row.module_barcode || row.module_barcode.length < 17) {
    console.warn(`⚠️ Skipping sr_no ${row.sr_no} due to invalid module_barcode`);
    return false;
  }
  return true;
}

function decodeDateFromBarcode(barcode) {
  const [yearChar, monthChar, dayChar] = barcode.substring(14, 17);
  return {
    year: yearMap[yearChar],
    month: monthMap[monthChar],
    day: dayMap[dayChar]
  };
}

function calculateDateFormats(year, month, day) {
  const packDateObj = dayjs(`${2000 + year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
  return {
    packDate: packDateObj.format('YYYY-MM-DD'),
    packDate_DDMMYY: packDateObj.format('DD_MM_YY'),
    packDate_DDMMYYYY: packDateObj.format('DD-MM-YYYY'),
    packDate_MMYY: packDateObj.format('MM_YY'),
    packDate_MMYYYY: packDateObj.format('MM-YYYY')
  };
}

function generateTableNames(dateFormats) {
  return {
    targetTable: `module_register_${dateFormats.packDate_DDMMYY}`,
    packTable: `Pack_Register_${dateFormats.packDate_MMYY}`
  };
}

async function ensureTablesExist(tableNames, createdTables, schema_table, schema_table2) {
  if (!createdTables.has(tableNames.targetTable)) {
    try {
      await withConnection('pool4', async (pool) => {
        await pool.request().query(`
          IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='${tableNames.targetTable}' AND xtype='U')
          CREATE TABLE [${schema_table}].[${tableNames.targetTable}] (
            srno INT IDENTITY(1,1) PRIMARY KEY,
            Pack_ID NVARCHAR(100),
            Module_ID NVARCHAR(100),
            Module_QR NVARCHAR(100),
            Line_ID NVARCHAR(100),
            Pack_creation_Date DATE,
            Pack_No NVARCHAR(100),
            Cur_Date DATETIME2(0) DEFAULT GETDATE(),
            operator_id NVARCHAR(100),
            operator_name NVARCHAR(100),
            updated_by NVARCHAR(100)
          )
        `);
        createdTables.add(tableNames.targetTable);
      });
    } catch (err) {
      console.error('Error creating target table:', err.message);
      throw err;
    }
  }

  if (!createdTables.has(tableNames.packTable)) {
    try {
      await withConnection('pool5', async (pool) => {
        await pool.request().query(`
          IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='${tableNames.packTable}' AND xtype='U')
          CREATE TABLE [${schema_table}].[${tableNames.packTable}] (
            srno INT IDENTITY(1,1) PRIMARY KEY,
            Line_ID NVARCHAR(100),
            Pack_ID NVARCHAR(100),
            Pack_No NVARCHAR(100),
            modules_creation_date NVARCHAR(MAX),
            Pack_creation_Date DATE,
            assign_stations_ids NVARCHAR(MAX),
            Interlock_on_stationIDs NVARCHAR(MAX),
            operator_id NVARCHAR(100),
            operator_name NVARCHAR(100),
            updated_by NVARCHAR(100)
          )
        `);
        createdTables.add(tableNames.packTable);
      });
    } catch (err) {
      console.error('Error creating pack table:', err.message);
      throw err;
    }
  }

  console.log(`[INFO] Skipping creation of module_status and pack_status tables - handled by API`);
}

function extractLast6Digits(qrCode) {
  if (!qrCode) {
    console.warn('⚠️ Skipping due to null final_qr_code');
    return null;
  }
  return qrCode.replace(/\D/g, '').slice(-6);
}

async function recordExists(module_barcode, tableName, schema) {
  return withConnection('pool4', async (pool) => {
    const result = await pool.request()
      .input('module_barcode', sql.NVarChar, module_barcode)
      .query(`SELECT 1 FROM [${schema}].[${tableName}] WHERE Module_QR = @module_barcode`);
    return result.recordset.length > 0;
  });
}

// ============================================================================
// UPDATE EXISTING RECORD
// ============================================================================
async function updateExistingRecord(row, dateFormats, tableNames, last6Digits, schema_table, schema_table2) {
  try {
    const operatorData = extractOperatorData(row);
    let allUpdatesSuccessful = true;
    
    // Update module register
    try {
      await withConnection('pool4', async (pool) => {
        await safeUpdateOperator(pool, schema_table, tableNames.targetTable, 'Module_QR', row.module_barcode, operatorData);
      });
    } catch (err) {
      console.warn(`⚠️ Could not update module register for ${row.module_barcode}:`, err.message);
      allUpdatesSuccessful = false;
    }
    
    return allUpdatesSuccessful;
  } catch (err) {
    console.error(`❌ Error updating existing record ${row.module_barcode}:`, err.message);
    return false;
  }
}

// ============================================================================
// GET PACK AND MODULE INFO
// ============================================================================
async function getPackAndModuleInfo(row) {
  return withConnection('pool2', async (pool2) => {
    const cleanPackName = row.battery_pack_name.replaceAll('|', ' ');
    const packRes = await pool2.request()
      .input('pack_name', sql.NVarChar, cleanPackName)
      .query(`SELECT Pack_ID FROM [taco_treceability_master].[taco_treceability].[master_pack] WHERE Pack_Name = @pack_name`);
   
    if (packRes.recordset.length === 0) {
      return null;
    }

    const packID = packRes.recordset[0].Pack_ID;
    
    const modRes = await pool2.request()
      .input('moduleNumber', sql.Int, row.moduleNumber)
      .input('packID', sql.Int, packID)
      .query(`SELECT Module_ID FROM [taco_treceability_master].[taco_treceability].[master_module] WHERE moduleNumber = @moduleNumber AND Pack_ID = @packID`);
   
    if (modRes.recordset.length === 0) {
      return null;
    }

    return {
      packID: packID,
      moduleID: modRes.recordset[0].Module_ID
    };
  });
}

// ============================================================================
// PROCESS PACK AND MODULE DATA
// ============================================================================
async function processPackAndModuleData(row, dateFormats, tableNames, last6Digits, schema_table, schema_table2) {
  const packMap = new Map();
  const insertResults = [];
  const operatorData = extractOperatorData(row);

  const packModuleInfo = await getPackAndModuleInfo(row);
  if (!packModuleInfo) {
    console.warn(`⚠️ No pack/module info found for ${row.battery_pack_name}`);
    insertResults.push({ table: 'all', success: false, error: 'No pack/module info found' });
    return insertResults;
  }

  const { packID, moduleID } = packModuleInfo;
  const lineID = lineMap[row.line];

  // Insert into module register
  const moduleRegisterData = {
    Pack_ID: packID,
    Module_ID: moduleID,
    Module_QR: row.module_barcode,
    Line_ID: lineID,
    Pack_creation_Date: dateFormats.packDate,
    Pack_No: last6Digits
  };

  Object.assign(moduleRegisterData, operatorData);

  const moduleRegisterResult = await withConnection('pool4', async (pool4) => {
    const result = await safeInsert(pool4, schema_table, tableNames.targetTable, moduleRegisterData);
    
    if (result.success) {
      await safeUpdateOperator(pool4, schema_table, tableNames.targetTable, 'Module_ID', moduleID, operatorData);
    }
    
    return result;
  });
  insertResults.push({ table: tableNames.targetTable, ...moduleRegisterResult });

  // INSERT MODULE STATUS VIA API - SINGLE CALL
  const moduleStatusResult = await insertModuleStatusViaAPI(
    packID,
    moduleID,
    last6Digits,
    dateFormats.packDate,
    lineID,
    operatorData
  );
  
  const apiModuleStatusResult = {
    table: 'API_module_status',
    success: moduleStatusResult.success || moduleStatusResult.skipped,
    error: moduleStatusResult.error,
    skipped: moduleStatusResult.skipped || false
  };
  insertResults.push(apiModuleStatusResult);

  // SEND MODULE TO STATION INTERLOCK API - NEW API CALL
  const interlockResult = await sendToStationInterlockAPI(
    row.module_barcode,
    lineID,
    row
  );
  
  const apiInterlockResult = {
    table: 'API_station_interlock',
    success: interlockResult.success || interlockResult.skipped,
    error: interlockResult.error,
    skipped: interlockResult.skipped || false
  };
  insertResults.push(apiInterlockResult);

  // Handle pack registration
  const packResults = await handlePackRegistration(
    row,
    packID,
    last6Digits,
    dateFormats,
    tableNames,
    schema_table,
    schema_table2,
    packMap,
    operatorData
  );
  insertResults.push(...packResults);

  // Update pack modules dates
  try {
    await updatePackModulesDates(packMap, tableNames.packTable, schema_table);
  } catch (err) {
    console.warn(`⚠️ Could not update pack modules dates:`, err.message);
  }

  return insertResults;
}

// ============================================================================
// HANDLE PACK REGISTRATION
// ============================================================================
async function handlePackRegistration(row, packID, packNo, dateFormats, tableNames, schema_table, schema_table2, packMap, operatorData) {
  const insertResults = [];
  const packExists = await withConnection('pool5', async (pool) => {
    const result = await pool.request()
      .input('packID', sql.Int, packID)
      .input('packNo', sql.NVarChar, packNo)
      .query(`SELECT 1 FROM [${schema_table}].[${tableNames.packTable}] WHERE Pack_ID = @packID AND Pack_No = @packNo`);
    return result.recordset.length > 0;
  });

  if (!packExists) {
    const packResult = await createNewPack(
      row, 
      packID, 
      packNo, 
      dateFormats, 
      tableNames, 
      schema_table, 
      schema_table2, 
      operatorData
    );
    insertResults.push({ table: tableNames.packTable, ...packResult.packResult });
    insertResults.push({ table: 'Pack_duplicate_checker', ...packResult.checkerResult });
  } else {
    // Update existing pack with operator data
    await withConnection('pool5', async (pool) => {
      await safeUpdateOperator(pool, schema_table, tableNames.packTable, 'Pack_ID', packID, operatorData);
    });
  }

  const packKey = `${packID}_${packNo}`;
  if (!packMap.has(packKey)) packMap.set(packKey, []);
  packMap.get(packKey).push(dateFormats.packDate);

  return insertResults;
}

// ============================================================================
// CREATE NEW PACK
// ============================================================================
async function createNewPack(row, packID, packNo, dateFormats, tableNames, schema_table, schema_table2, operatorData) {
  const results = {};

  // Insert into Pack_Register
  const packData = {
    Line_ID: lineMap[row.line],
    Pack_ID: packID,
    Pack_No: packNo,
    modules_creation_date: '',
    Pack_creation_Date: dateFormats.packDate,
    assign_stations_ids: '3,7,8,9,10,11,12,13,14,15,16,17,18,19,3015,3016,3011,3012,3013,3014,20,21,22,3007,3008,3009,3010',
    Interlock_on_stationIDs: '1,20,21,22,3009,3010,3008,3011,3012,3013,3014,7,8,9,10,11,12,13,14,3015,3016,4,15,16,18,19,3,30,3021,3022,3023,3024,3026,28,33,39,32,2,29,5,35,40,41,3025,3028,3035,3036'
  };

  Object.assign(packData, operatorData);

  results.packResult = await withConnection('pool5', async (pool) => {
    const result = await safeInsert(pool, schema_table, tableNames.packTable, packData);
    
    if (result.success) {
      await safeUpdateOperator(pool, schema_table, tableNames.packTable, 'Pack_ID', packID, operatorData);
    }
    
    return result;
  });

  // Insert into Pack_duplicate_checker
  const checkerData = {
    Line_Id: lineMap[row.line],
    Pack_ID: packID,
    Pack_No: packNo,
    pack_creation_Date: dateFormats.packDate,
    new_series: 'NA',
    auto_reset_date: ''
  };

  Object.assign(checkerData, operatorData);

  results.checkerResult = await withConnection('pool6', async (pool) => {
    const result = await safeInsert(pool, schema_table2, 'Pack_duplicate_checker', checkerData);
    
    if (result.success) {
      await safeUpdateOperator(pool, schema_table2, 'Pack_duplicate_checker', 'Pack_ID', packID, operatorData);
    }
    
    return result;
  });

  // PACK STATUS HANDLING VIA API - SINGLE CALL
  const packStatusResult = await insertPackStatusViaAPI(
    packID,
    packNo,
    dateFormats.packDate,
    lineMap[row.line],
    operatorData
  );
  
  results.statusResult = { 
    success: packStatusResult.success || packStatusResult.skipped, 
    api_handled: true,
    skipped: packStatusResult.skipped || false
  };

  return results;
}

// ============================================================================
// UPDATE PACK MODULES DATES
// ============================================================================
async function updatePackModulesDates(packMap, packTable, schema) {
  for (const [packKey, dates] of packMap.entries()) {
    const [packID, packNo] = packKey.split('_');
    const uniqueDates = [...new Set(dates)].join(',');
   
    try {
      await withConnection('pool5', async (pool) => {
        await pool.request()
          .input('packID', sql.Int, packID)
          .input('packNo', sql.NVarChar, packNo)
          .input('uniqueDates', sql.NVarChar, uniqueDates)
          .query(`
            UPDATE [${schema}].[${packTable}]
            SET modules_creation_date = @uniqueDates
            WHERE Pack_ID = @packID AND Pack_No = @packNo
          `);
      });
    } catch (err) {
      console.warn(`⚠️ Could not update pack modules dates for ${packKey}:`, err.message);
    }
  }
}

// ============================================================================
// CLEANUP PROCESSED RECORDS
// ============================================================================
async function cleanupProcessedRecords(processingResults) {
  const { processedSrNos, failedInserts } = processingResults;
  
  if (processedSrNos.length === 0) {
    console.log('No successfully processed records to clean up');
    return;
  }

  const uniqueSrNos = [...new Set(processedSrNos)];
  const chunkSize = 1000;
 
  for (let i = 0; i < uniqueSrNos.length; i += chunkSize) {
    const chunk = uniqueSrNos.slice(i, i + chunkSize);
    try {
      await withConnection('pool1', async (pool) => {
        await pool.request()
          .query(`DELETE FROM taco_treceability.master_compress_data WHERE sr_no IN (${chunk.join(',')})`);
      });
    } catch (err) {
      console.error(`❌ Error deleting chunk ${i/chunkSize + 1}:`, err.message);
    }
  }
  
  console.log(`Cleaned up ${uniqueSrNos.length} successfully processed records`);
  
  if (failedInserts.length > 0) {
    console.warn(`⚠️ ${failedInserts.length} records failed to insert into all tables:`);
    failedInserts.forEach(failed => {
      console.warn(`  - sr_no ${failed.sr_no}: ${failed.errors.join(', ')}`);
    });
  }
}

// ============================================================================
// PROCESS CONTROL
// ============================================================================
let isProcessing = false;

async function safeProcessRecords() {
  if (isProcessing) {
    console.log('Processing already in progress, skipping this run');
    return;
  }

  try {
    isProcessing = true;
    await processRecords();
  } catch (err) {
    console.error(' Error in safeProcessRecords:', err.message);
  } finally {
    isProcessing = false;
  }
}

// Handle process termination gracefully
process.on('SIGINT', async () => {
  console.log(' Received SIGINT. Shutting down gracefully...');
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log(' Received SIGTERM. Shutting down gracefully...');
  process.exit(0);
});

// Start processing
console.log('Starting enhanced record processing service with API integration...');
console.log('[INFO] Features enabled:');
console.log('[INFO] 1. Insert/update operator data in all tables');
console.log('[INFO] 2. Safe insert with missing column handling');
console.log('[INFO] 3. Only delete after successful insertion to all tables');
console.log('[INFO] 4. Update existing records');
console.log('[INFO] 5. API integration for module/pack status');
console.log('[INFO] 6. NEW: Station interlock API integration');
console.log('[INFO]   - Module status inserted via API (ONE TIME ONLY)');
console.log('[INFO]   - Pack status handled via API (ONE TIME ONLY)');
console.log('[INFO]   - Module sent to station interlock API (ONE TIME ONLY)');
console.log('[INFO]   - Global tracking prevents duplicate API calls');

// Start the processing interval
setInterval(safeProcessRecords, 1000);