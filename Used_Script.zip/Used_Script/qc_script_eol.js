const sql = require("mssql");
const EventEmitter = require("events");
EventEmitter.defaultMaxListeners = 20;

// ---------------- DB CONFIG ------------------
const poolEOL = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "taco_treceability",
  options: { encrypt: true, trustServerCertificate: true }
});

const poolPackMaster = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "taco_treceability_master",
  options: { encrypt: true, trustServerCertificate: true }
});

const poolDuplicateChecker = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "cell_scanning_master",
  options: { encrypt: true, trustServerCertificate: true }
});

const poolPackStatus = new sql.ConnectionPool({
  user: 'user_mis',
  password: 'admin',
  server: '10.9.4.28\\MSSQLSERVER',
  database: 'taco_treceability_station_status',
  options: { encrypt: true, trustServerCertificate: true }
});

// ---------------- HELPER ------------------
function generatePackStatusWithTimestamp(oldStatus) {
  const now = new Date();
  const istOffset = 5.5 * 60 * 60 * 1000;
  const istDate = new Date(now.getTime() + istOffset);
  const timestamp = istDate.toISOString().slice(0, 19).replace('T', ' ').replace(/:/g, '.');

  const parts = oldStatus.split(':');
  const substations = parts[1] || 'NA';
  const interlock = parts[2] || '2';

  return `OK|${timestamp}:${substations}:${interlock}`;
}

// ---------------- MAIN PROCESS ------------------
async function processEOL() {
  try {
    if (!poolEOL.connected) await poolEOL.connect();
    if (!poolPackMaster.connected) await poolPackMaster.connect();
    if (!poolDuplicateChecker.connected) await poolDuplicateChecker.connect();
    if (!poolPackStatus.connected) await poolPackStatus.connect();

    const qrRes = await poolEOL.request().query(`
      SELECT DISTINCT FinalQRCode, PackName
      FROM taco_treceability.station_status_eol
    `);

    console.log(`Found ${qrRes.recordset.length} QR codes`);

    for (const row of qrRes.recordset) {
      const finalQR = row.FinalQRCode;
      const packName = row.PackName;

      // 🔒 EACH QR IS ISOLATED
      try {
        if (!finalQR || finalQR.length < 6) {
          console.warn(`Skipping invalid QR = ${finalQR}`);
          continue;
        }

        const packNo = finalQR.slice(-6);
        const cleanPackName = packName.replaceAll("|", " ");

        console.log(`\n🔍 Processing QR = ${finalQR}`);

        // 1️⃣ PACK ID
        const packRes = await poolPackMaster.request()
          .input("name", sql.NVarChar, cleanPackName)
          .query(`
            SELECT Pack_ID
            FROM taco_treceability_master.taco_treceability.master_pack
            WHERE Pack_Name = @name
          `);

        if (packRes.recordset.length === 0) {
          console.warn(`⚠ No Pack_ID found`);
          continue;
        }

        const packID = packRes.recordset[0].Pack_ID;

        // 2️⃣ DUP CHECK
        const dupRes = await poolDuplicateChecker.request()
          .input("pid", sql.Int, packID)
          .input("pno", sql.Int, packNo)
          .query(`
            SELECT TOP 1 pack_creation_Date, Line_Id
            FROM Pack_duplicate_checker
            WHERE Pack_ID = @pid AND Pack_No = @pno
          `);

        if (dupRes.recordset.length === 0) {
          console.warn(`⚠ No pack_creation_Date found for Pack_No=${packNo}`);
          continue; // ✅ DOES NOT STOP OTHER RECORDS
        }

        const packDate = dupRes.recordset[0].pack_creation_Date;
        const lineId = dupRes.recordset[0].Line_Id;
        const dt = new Date(packDate);

        const month = String(dt.getMonth() + 1).padStart(2, "0");
        const year = dt.getFullYear();
        const tableName = `[dbo].[pack_status_${month}-${year}]`;

        // 3️⃣ OLD STATUS
        const oldRes = await poolPackStatus.request()
          .input("pid", sql.Int, packID)
          .input("pno", sql.VarChar, packNo)
          .query(`
            SELECT [EOL] old_status
            FROM ${tableName}
            WHERE Pack_ID = @pid AND Pack_No = @pno
          `);

        const oldStatus = oldRes.recordset[0]?.old_status || null;

        // 4️⃣ NEW STATUS
        const newStatus = oldStatus
          ? generatePackStatusWithTimestamp(oldStatus)
          : generatePackStatusWithTimestamp('NOT OK:NA:2');

        // 5️⃣ UPDATE
        await poolPackStatus.request()
          .input("status", sql.NVarChar(sql.MAX), newStatus)
          .input("pid", sql.Int, packID)
          .input("pno", sql.VarChar, packNo)
          .query(`
            UPDATE ${tableName}
            SET [EOL] = @status
            WHERE Pack_ID = @pid AND Pack_No = @pno
          `);

        // 6️⃣ DELETE FROM QUEUE
        await poolEOL.request()
          .input("qr", sql.NVarChar, finalQR)
          .query(`
            DELETE FROM taco_treceability.station_status_eol
            WHERE FinalQRCode = @qr
          `);

        console.log(`✅ Completed QR = ${finalQR}`);

      } catch (qrError) {
        // 🚨 THIS IS THE MOST IMPORTANT PART
        console.error(`❌ QR FAILED = ${finalQR}`, qrError.message);
        continue; // ✅ MOVE TO NEXT QR
      }
    }

  } catch (err) {
    console.error("❌ PROCESS ERROR:", err.message);
  }
}

// ---------------- RUNNER ------------------
setInterval(processEOL, 3000);
processEOL();
