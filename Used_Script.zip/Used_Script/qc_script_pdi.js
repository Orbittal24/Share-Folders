const sql = require("mssql");
const EventEmitter = require("events");
EventEmitter.defaultMaxListeners = 20;

// ---------------- DB CONFIG ------------------
const poolPDI = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "taco_treceability",
  options: { encrypt: true, trustServerCertificate: true }
});

const poolPackMaster = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "taco_treceability_master",
  options: { encrypt: true, trustServerCertificate: true }
});

const poolDuplicateChecker = new sql.ConnectionPool({
  user: "user_mis",
  password: "admin",
  server: "10.9.4.28\\MSSQLSERVER",
  database: "cell_scanning_master",
  options: { encrypt: true, trustServerCertificate: true }
});

// ⭐ NEW DB for pack_status_****** tables
const poolPackStatus = new sql.ConnectionPool({
  user: 'user_mis',
  password: 'admin',
  server: '10.9.4.28\\MSSQLSERVER',
  database: 'taco_treceability_station_status',
  options: { 
    encrypt: true, 
    trustServerCertificate: true,
    connectTimeout: 30000,
    requestTimeout: 60000
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
});

// ============================================================================
// CHANGE #1: NEW DATABASE CONFIG FOR COMPLETION TRACKING
// Added by: Abhay | Date: 2025-12-12
// Purpose: Track pack completion history in separate database
// Location: After poolPackStatus (line 48)
// ============================================================================
const historyConfig = {
  user: 'user_mis',
  password: 'admin',
  server: '10.9.4.28\\MSSQLSERVER',
  database: 'taco_treceability_station_status_history',
  options: { encrypt: true, trustServerCertificate: true }
};

// ============================================================================
// CHANGE #2: HELPER FUNCTION FOR TIMESTAMP FORMAT
// Added by: Abhay | Date: 2025-12-12
// Purpose: Generate pack status with timestamp (OK|YYYY-MM-DD HH.MM.SS:substations:interlock)
// Location: Before processPDI function
// ============================================================================
function generatePackStatusWithTimestamp(oldStatus) {
  const now = new Date();
  // Convert to IST (UTC+5:30)
  const istOffset = 5.5 * 60 * 60 * 1000;
  const istDate = new Date(now.getTime() + istOffset);
  const timestamp = istDate.toISOString().slice(0, 19).replace('T', ' ').replace(/:/g, '.');
  
  // Extract substations and interlock from old status
  // Format: "NOT OK:substations:interlock" or "OK:substations:interlock"
  const parts = oldStatus.split(':');
  const substations = parts[1] || 'NA';
  const interlock = parts[2] || 'NA';
  
  return `OK|${timestamp}:${substations}:${interlock}`;
}
// ============================================================================
// CHANGE #3: COMPLETION TRACKING FUNCTION
// Added by: Abhay | Date: 2025-12-12
// Purpose: Log pack completion to daily history table
// Location: After generatePackStatusWithTimestamp
// Notes:
//  - Creates table pack_completion_DD_MM_YYYY if not exists
//  - Inserts completion record with pack_id, pack_no, station, timestamp
//  - Non-blocking: catches errors silently to avoid disrupting main flow
// ============================================================================
async function trackPackCompletion(packID, packNo, lineID, stationName, statusValue) {
  let historyPool = null;
  try {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const tableName = `pack_completion_${day}_${month}_${year}`;
    
    historyPool = await new sql.ConnectionPool(historyConfig).connect();
    
    // Create table if not exists
    await historyPool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '${tableName}')
      BEGIN
        CREATE TABLE ${tableName} (
          id INT IDENTITY(1,1) PRIMARY KEY,
          pack_id INT NOT NULL,
          pack_no NVARCHAR(255) NOT NULL,
          line_id INT,
          station_name NVARCHAR(255) NOT NULL,
          completion_time DATETIME NOT NULL DEFAULT GETDATE(),
          status_value NVARCHAR(255),
          INDEX idx_pack_id (pack_id),
          INDEX idx_pack_no (pack_no),
          INDEX idx_line_id (line_id),
          INDEX idx_station_name (station_name),
          INDEX idx_completion_time (completion_time)
        )
      END
    `);
    
    // Insert completion record
    await historyPool.request()
      .input('pack_id', sql.Int, packID)
      .input('pack_no', sql.NVarChar, packNo)
      .input('line_id', sql.Int, lineID)
      .input('station_name', sql.NVarChar, stationName)
      .input('status_value', sql.NVarChar, statusValue)
      .query(`
        INSERT INTO ${tableName}
        (pack_id, pack_no, line_id, station_name, status_value)
        VALUES (@pack_id, @pack_no, @line_id, @station_name, @status_value)
      `);
    
    console.log(`[TRACKING] ✅ Logged ${stationName} completion for Pack ${packNo} (ID: ${packID})`);
  } catch (err) {
    console.error('[TRACKING] ⚠️ Failed to log completion (non-blocking):', err.message);
  } finally {
    if (historyPool) {
      try {
        await historyPool.close();
      } catch (_) {}
    }
  }
}

// ---------------- MAIN PROCESS ------------------
async function processPDI() {
  try {
    await poolPDI.connect();
    await poolPackMaster.connect();
    await poolDuplicateChecker.connect();
    await poolPackStatus.connect();      // ⭐ NEW CONNECTION

    // 1️⃣ GET DISTINCT FinalQRCode
    const qrQuery = `
      SELECT DISTINCT FinalQRCode, PackName
      FROM taco_treceability.station_status_pdi
    `;

    const qrRes = await poolPDI.request().query(qrQuery);
    console.log(`Found ${qrRes.recordset.length} QR codes`);

    for (const row of qrRes.recordset) {
      const finalQR = row.FinalQRCode;
      const packName = row.PackName;

      if (!finalQR || finalQR.length < 6) {
        console.warn(`Skipping invalid QR = ${finalQR}`);
        continue;
      }

      const packNo = finalQR.slice(-6);
      const cleanPackName = packName.replaceAll("|", " ");

      console.log(`\n🔍 Processing QR = ${finalQR} | Pack_No = ${packNo}`);

      // 2️⃣ GET Pack_ID
      const packQuery = `
        SELECT Pack_ID
        FROM taco_treceability_master.taco_treceability.master_pack
        WHERE Pack_Name = @name
      `;

      const packRes = await poolPackMaster
        .request()
        .input("name", sql.NVarChar, cleanPackName)
        .query(packQuery);

      if (packRes.recordset.length === 0) {
        console.warn(`⚠ No Pack_ID found for packName=${cleanPackName}`);
        continue;
      }

      const packID = packRes.recordset[0].Pack_ID;
      console.log(`✔ Pack_ID = ${packID}`);

      // 3️⃣ Get pack creation date and Line_Id
      const dupQuery = `
        SELECT TOP 1 pack_creation_Date, Line_Id
        FROM Pack_duplicate_checker
        WHERE Pack_ID = @pid AND Pack_No = @pno
      `;

      const dupRes = await poolDuplicateChecker
        .request()
        .input("pid", sql.Int, packID)
        .input("pno", sql.Int, packNo)
        .query(dupQuery);

      if (dupRes.recordset.length === 0) {
        console.warn(`⚠ No pack_creation_Date found`);
        continue;
      }

      const packDate = dupRes.recordset[0].pack_creation_Date;
      const lineId = dupRes.recordset[0].Line_Id;
      const dt = new Date(packDate);

      const month = String(dt.getMonth() + 1).padStart(2, "0");
      const year = dt.getFullYear();

      // ⭐ CORRECTED: use underscore instead of hyphen
      const tableName = `pack_status_${month}-${year}`;
      const statusTable = `[dbo].[${tableName}]`;

      console.log(`✔ Updating table = ${statusTable}`);

      // ============================================================================
      // CHANGE #4: GET OLD STATUS BEFORE UPDATE
      // Modified by: Abhay | Date: 2025-12-12
      // Purpose: Capture old [PDI] status to detect completion
      // Location: Lines 236-248 (before UPDATE query)
      // ============================================================================
      const selectQuery = `
        SELECT [PDI] as old_status
        FROM ${statusTable}
        WHERE [Pack_ID] = @packID AND [Pack_No] = @packNo
      `;
      const oldStatusResult = await poolPackStatus
        .request()
        .input("packID", sql.Int, packID)
        .input("packNo", sql.VarChar, packNo)
        .query(selectQuery);
      
      const oldStatus = oldStatusResult.recordset.length > 0 
        ? oldStatusResult.recordset[0].old_status 
        : null;
      console.log(`📋 Pack ${packNo} | Old [PDI] status: ${oldStatus}`);

      // ============================================================================
      // CHANGE #5: GENERATE TIMESTAMP STATUS
      // Modified by: Abhay | Date: 2025-12-12
      // Purpose: Create new status with timestamp format
      // Location: Lines 250-256 (before UPDATE query)
      // ============================================================================
     const newStatus = oldStatus
  ? generatePackStatusWithTimestamp(oldStatus)
  : (() => {
      const now = new Date();
      const istOffset = 5.5 * 60 * 60 * 1000;
      const istDate = new Date(now.getTime() + istOffset);
      return 'OK|' + istDate.toISOString().slice(0, 19).replace('T', ' ').replace(/:/g, '.') + ':NA:3012,3013,19,4,3021,3022,5,3025';
    })();

      // 4️⃣ UPDATE STATUS (MODIFIED to use newStatus)
      const updateSql = `
        UPDATE ${statusTable}
        SET [PDI] = @newStatus
        WHERE pack_id = @pid AND pack_no = @pno
      `;

      const updateRes = await poolPackStatus
        .request()
        .input("newStatus", sql.NVarChar(sql.MAX), newStatus)  // ⬅️ CHANGED: Use newStatus
        .input("pid", sql.Int, packID)
        .input("pno", sql.Int, packNo)
        .query(updateSql);

      console.log(`✅ PDI Updated (Rows affected: ${updateRes.rowsAffected})`);

      // ============================================================================
      // CHANGE #6: TRACK COMPLETION
      // Added by: Abhay | Date: 2025-12-12
      // Purpose: Log completion if NOT OK -> OK transition
      // Location: Lines 278-288 (after UPDATE query)
      // Notes: Non-blocking async call, only tracks actual completions
      // ============================================================================
      if (oldStatus && oldStatus.includes('NOT OK')) {
        console.log(`[TRACKING] 🎯 Detected completion: NOT OK -> OK`);
        trackPackCompletion(packID, packNo, lineId, 'PDI', newStatus).catch(err => {
          console.error('[TRACKING] ⚠️ Background tracking failed:', err.message);
        });
      } else {
        console.log(`[TRACKING] ℹ️  Skipped - not a completion (old status: ${oldStatus})`);
      }

      // 5️⃣ DELETE processed rows
      const delSql = `
        DELETE FROM taco_treceability.station_status_pdi
        WHERE FinalQRCode = @qr
      `;

      await poolPDI.request().input("qr", sql.NVarChar, finalQR).query(delSql);

      console.log(`🗑 Deleted rows for QR = ${finalQR}`);
    }
  } catch (err) {
    console.error("❌ ERROR:", err);
  }
}

// Run every 3 seconds
setInterval(processPDI, 3000);
processPDI();
