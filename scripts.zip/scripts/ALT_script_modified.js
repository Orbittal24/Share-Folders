const sql = require("mssql");
const axios = require("axios");

const config = {
  user: "user_mis",
  password: "admin",
  database: "taco_treceability",
  server: "10.9.4.28",
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// ============================================================================
// CHANGE #1: NEW DATABASE CONNECTION FOR COMPLETION TRACKING
// Added by: Abhay | Date: 2025-12-12
// Purpose: Track pack completion history in separate database
// Lines: 20-32
// ============================================================================
const historyConfig = {
  user: "user_mis",
  password: "admin",
  database: "taco_treceability_station_status_history",
  server: "10.9.4.28",
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// === Helper to clean pack names ===
function cleanPackName(name) {
  if (!name) return null;

  if (name.startsWith("EBUS_")) {
    const match = name.match(/^EBUS_(\d{3,4})$/);
    if (match) {
      let digits = match[1];
      if (digits.length === 4) digits = digits.slice(0, 3);
      return `EBUS ${digits}`;
    }
  }
  return name;
}

// === Helper to format date into MM-YYYY ===
function formatMonthYear(dateString) {
  const date = new Date(dateString);
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${month}-${year}`;
}

// ============================================================================
// CHANGE #2: HELPER FUNCTION FOR TIMESTAMP FORMAT
// Added by: Abhay | Date: 2025-12-12
// Purpose: Generate status string with timestamp (OK|2025-12-12 10:30:45:1:22,3023)
// Format: STATUS|TIMESTAMP:SUBSTATIONS:INTERLOCK
// Lines: 67-76
// ============================================================================
function generatePackStatusWithTimestamp(oldStatus) {
  const now = new Date();
  const timestamp = now.toISOString().slice(0, 19).replace('T', ' ').replace(/:/g, '.');
  
  // Extract substations and interlock from old status (NOT OK:1:22,3023 -> 1 and 22,3023)
  const parts = oldStatus.split(':');
  const substations = parts[1] || 'NA';
  const interlock = parts[2] || 'NA';
  
  return `OK|${timestamp}:${substations}:${interlock}`;
}

// ============================================================================
// CHANGE #3: COMPLETION TRACKING FUNCTION
// Added by: Abhay | Date: 2025-12-12
// Purpose: Log pack completion to history database
// Table: pack_completion_DD_MM_YYYY (daily tables)
// Non-blocking: Silent fail to prevent disruption
// Lines: 78-134
// ============================================================================
async function trackPackCompletion(packID, packNo, lineID, stationName, statusValue) {
  let historyPool = null;
  try {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const tableName = `pack_completion_${day}_${month}_${year}`;
    
    historyPool = await new sql.ConnectionPool(historyConfig).connect();
    
    // Create table if it doesn't exist (daily table)
    await historyPool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '${tableName}')
      BEGIN
        CREATE TABLE ${tableName} (
          id INT IDENTITY(1,1) PRIMARY KEY,
          pack_id INT NOT NULL,
          pack_no NVARCHAR(255) NOT NULL,
          line_id INT,
          station_name NVARCHAR(255) NOT NULL,
          completion_time DATETIME NOT NULL DEFAULT GETDATE(),
          status_value NVARCHAR(255),
          
          INDEX idx_pack_id (pack_id),
          INDEX idx_pack_no (pack_no),
          INDEX idx_line_id (line_id),
          INDEX idx_station_name (station_name),
          INDEX idx_completion_time (completion_time)
        )
      END
    `);
    
    // Insert completion record
    await historyPool.request()
      .input('pack_id', sql.Int, packID)
      .input('pack_no', sql.NVarChar, packNo)
      .input('line_id', sql.Int, lineID)
      .input('station_name', sql.NVarChar, stationName)
      .input('status_value', sql.NVarChar, statusValue)
      .query(`
        INSERT INTO ${tableName}
        (pack_id, pack_no, line_id, station_name, status_value)
        VALUES (@pack_id, @pack_no, @line_id, @station_name, @status_value)
      `);
    
    console.log(`[TRACKING] ✅ Logged ${stationName} completion for Pack ${packNo}`);
  } catch (err) {
    // Silent fail - don't break main process if tracking fails
    console.error('[TRACKING] ⚠️ Failed to log completion:', err.message);
  } finally {
    if (historyPool) {
      await historyPool.close();
    }
  }
}

async function pollDataAndSend() {
  console.log("⏳ Starting data polling...");

  try {
    console.log("🔌 Connecting to SQL Server...");
    await sql.connect(config);
    console.log("✅ Connected to SQL Server.");

    console.log("📥 Fetching data from mirror_air_leakage_testing...");
    const result = await sql.query(`
  SELECT *
  FROM [taco_treceability].[mirror_air_leakage_testing]
  WHERE final_qrcode IN (
    SELECT final_qrcode
    FROM [taco_treceability].[mirror_air_leakage_testing]
    GROUP BY final_qrcode
    HAVING COUNT(*) = SUM(CASE WHEN body_coolant_status = 'OK' THEN 1 ELSE 0 END)
  )
`);

    const rows = result.recordset;
    console.log(`📊 Found ${rows.length} row(s) with status 'OK'.`);

    if (rows.length === 0) {
      console.log("📭 No data to process.");
      return;
    }

    for (const row of rows) {
      const cleanedName = cleanPackName(row.battery_pack_name);

      const payload = {
        sr_no: row.sr_no,
        battery_pack_name: cleanedName || null,
        final_qrcode: row.final_qrcode || null,
        checked_by: row.checked_by || null,
        status: row.status || null,
        body_reading: row.body_reading || null,
        body_reading_unit: row.body_reading_unit || null,
        coolant_reading: row.coolant_reading || null,
        coolant_reading_unit: row.coolant_reading_unit || null,
        body_coolant_status: row.body_coolant_status || null,
      };

      console.log(
        `📤 Cleaned payload for sr_no ${row.sr_no} (original: ${row.battery_pack_name} → cleaned: ${cleanedName}):`,
        payload
      );

      try {
        console.log(`🚀 Sending sr_no: ${row.sr_no} to FastAPI...`);
        const response = await axios.post(
          "https://mismainapp.tataautocomp.com:3241/api/v1/ALT_Database_Sync/ALT_Database_Sync",
          payload
        );

        if (response.data && response.data.success) {
          console.log(`✅ Processed sr_no ${row.sr_no}. Deleting from DB...`);

          // === Delete by sr_no ===
          await sql.query`
            DELETE FROM [taco_treceability].[mirror_air_leakage_testing]
            WHERE sr_no = ${row.sr_no}
          `;
          console.log(`🗑️ Deleted sr_no ${row.sr_no} successfully.`);

          // === Delete duplicate 'NOT OK' rows ===
          const deleteResult = await sql.query`
            DELETE FROM [taco_treceability].[mirror_air_leakage_testing]
            WHERE final_qrcode = ${row.final_qrcode}
              AND body_coolant_status = 'NOT OK'
          `;
          if (deleteResult.rowsAffected[0] > 0) {
            console.log(
              `🗑️ Deleted ${deleteResult.rowsAffected[0]} row(s) with final_qrcode=${row.final_qrcode} AND status='NOT OK'.`
            );
          } else {
            console.log(
              `ℹ️ No rows found to delete for final_qrcode=${row.final_qrcode} AND status='NOT OK'.`
            );
          }

          // === EXTRA: Update pack status table ===
          try {
            // Step 1: Get Pack_ID from packs API
            console.log(`🌐 Fetching Pack_ID for ${cleanedName}...`);
            const packResponse = await axios.get(
              `https://mismainapp.tataautocomp.com:3241/packs?Pack_Name=${encodeURIComponent(
                cleanedName
              )}`
            );

            if (packResponse.data && packResponse.data.length > 0) {
              const { Pack_ID } = packResponse.data[0];
              console.log(`📦 Found Pack_ID: ${Pack_ID}`);

              // Step 2: Get last 6 digits of final_qrcode
              const packNo = row.final_qrcode
                ? row.final_qrcode.slice(-6)
                : null;
              if (!packNo) {
                console.warn(
                  `⚠️ Could not extract Pack_No from final_qrcode for sr_no ${row.sr_no}. Skipping update.`
                );
                continue;
              }

              // Step 3: Get Pack creation date from pack-duplicates API
              console.log(
                `🌐 Fetching Pack_creation_Date for Pack_No=${packNo}, Pack_ID=${Pack_ID}...`
              );
              const duplicateResponse = await axios.get(
                `https://mismainapp.tataautocomp.com:3241/pack-duplicates?Pack_No=${packNo}&Pack_ID=${Pack_ID}`
              );

              if (
                duplicateResponse.data &&
                duplicateResponse.data.length > 0
              ) {
                const { Pack_creation_Date, Line_Id } = duplicateResponse.data[0];
                console.log(`📅 Pack creation date: ${Pack_creation_Date}`);

                const monthYear = formatMonthYear(Pack_creation_Date);
                const tableName = `[taco_treceability_station_status].[dbo].[pack_status_${monthYear}]`;
                console.log(`🧾 Target table: ${tableName}`);

                // ============================================================================
                // CHANGE #4: GET OLD STATUS BEFORE UPDATE
                // Modified by: Abhay | Date: 2025-12-12
                // Purpose: Capture old status to check if this is a completion (NOT OK -> OK)
                // Lines: 279-292
                // ============================================================================
                console.log(
                  `🔍 Fetching current [ALT] status for Pack_ID=${Pack_ID}, Pack_No=${packNo}...`
                );
                const selectQuery = `
                  SELECT [ALT] as old_status
                  FROM ${tableName}
                  WHERE [Pack_ID] = @Pack_ID AND [Pack_No] = @Pack_No
                `;
                const selectRequest = new sql.Request();
                selectRequest.input("Pack_ID", sql.Int, Pack_ID);
                selectRequest.input("Pack_No", sql.VarChar, packNo);
                const selectResult = await selectRequest.query(selectQuery);

                const oldStatus = selectResult.recordset.length > 0 
                  ? selectResult.recordset[0].old_status 
                  : null;
                console.log(`📋 Old [ALT] status: ${oldStatus}`);

                // ============================================================================
                // CHANGE #5: GENERATE TIMESTAMP STATUS
                // Modified by: Abhay | Date: 2025-12-12
                // Purpose: Create new status with timestamp format
                // Old: REPLACE([ALT], 'NOT OK', 'OK')
                // New: OK|2025-12-12 10:30:45:1:22,3023
                // Lines: 294-298
                // ============================================================================
                const newStatus = oldStatus 
                  ? generatePackStatusWithTimestamp(oldStatus)
                  : 'OK|' + new Date().toISOString().slice(0, 19).replace('T', ' ').replace(/:/g, '.') + ':NA:NA';
                console.log(`📋 New [ALT] status: ${newStatus}`);

                // Step 4: Update [ALT] column
                console.log(
                  `🛠️ Updating [ALT] column in ${tableName} for Pack_ID=${Pack_ID}, Pack_No=${packNo}...`
                );
                const updateQuery = `
                  UPDATE ${tableName}
                  SET [ALT] = @new_status
                  WHERE [Pack_ID] = @Pack_ID AND [Pack_No] = @Pack_No
                `;

                const request = new sql.Request();
                request.input("Pack_ID", sql.Int, Pack_ID);
                request.input("Pack_No", sql.VarChar, packNo);
                request.input("new_status", sql.VarChar, newStatus);
                const resultUpdate = await request.query(updateQuery);

                if (resultUpdate.rowsAffected[0] > 0) {
                  console.log(
                    `✅ Updated [ALT] status to ${newStatus} for Pack_ID=${Pack_ID}, Pack_No=${packNo} in ${tableName}.`
                  );

                  // ============================================================================
                  // CHANGE #6: TRACK COMPLETION IN HISTORY DATABASE
                  // Added by: Abhay | Date: 2025-12-12
                  // Purpose: Log pack completion if status changed from NOT OK to OK
                  // Non-blocking call - runs async without waiting
                  // Lines: 326-334
                  // ============================================================================
                  if (oldStatus && oldStatus.includes('NOT OK')) {
                    console.log(`[TRACKING] 🎯 Detected completion: NOT OK -> OK`);
                    trackPackCompletion(Pack_ID, packNo, Line_Id || null, 'ALT', newStatus).catch(err => {
                      console.error('[TRACKING] ⚠️ Background tracking failed:', err.message);
                    });
                  } else {
                    console.log(`[TRACKING] ℹ️ Skipped - not a completion (old status: ${oldStatus})`);
                  }
                } else {
                  console.log(
                    `ℹ️ No matching record found in ${tableName} for Pack_ID=${Pack_ID}, Pack_No=${packNo}.`
                  );
                }
              } else {
                console.warn(
                  `⚠️ No pack duplicate found for Pack_No=${packNo}, Pack_ID=${Pack_ID}`
                );
              }
            } else {
              console.warn(
                `⚠️ No Pack_ID found for Pack_Name=${cleanedName}`
              );
            }
          } catch (updateErr) {
            console.error(
              `❌ Error during pack status update for sr_no ${row.sr_no}: ${updateErr.message}`
            );
          }
        } else {
          console.warn(
            `⚠️ API responded with failure for sr_no ${row.sr_no}:`,
            response.data.message || response.data
          );
        }
      } catch (err) {
        console.error(`❌ Error while sending sr_no ${row.sr_no}: ${err.message}`);
      }
    }
  } catch (err) {
    console.error("❌ Database or Axios Error:", err.message);
  } finally {
    console.log("🔒 Closing SQL connection...");
    await sql.close();
    console.log("✅ SQL connection closed.");
  }

  console.log("✅ Poll cycle complete. Waiting for next interval...");
}

// Poll every 60 seconds
setInterval(pollDataAndSend, 60000);

// Run immediately on start
console.log("🚀 Starting ALT script with completion tracking enabled...");
console.log("[INFO] Tracking enabled - logging to taco_treceability_station_status_history");
pollDataAndSend();
