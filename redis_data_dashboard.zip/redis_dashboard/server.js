const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
const { createClient } = require("redis");

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3200);

const redisOptions = {
  socket: {
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: Number(process.env.REDIS_PORT || 6379),
  },
  database: Number(process.env.REDIS_DB || 8),
};

if (String(process.env.REDIS_TLS).toLowerCase() === "true") {
  redisOptions.socket.tls = true;
}
if (process.env.REDIS_USERNAME) redisOptions.username = process.env.REDIS_USERNAME;
if (process.env.REDIS_PASSWORD) redisOptions.password = process.env.REDIS_PASSWORD;

const redis = createClient(redisOptions);

redis.on("error", (err) => {
  console.error("Redis error:", err.message);
});

async function ensureRedis() {
  if (!redis.isOpen) await redis.connect();
}

function safeJsonParse(value) {
  if (typeof value !== "string") return value;
  try { return JSON.parse(value); } catch { return value; }
}

async function getRedisValue(key) {
  await ensureRedis();

  const type = await redis.type(key);

  if (type === "string") {
    const value = await redis.get(key);
    return { type, value: safeJsonParse(value), raw: value };
  }

  if (type === "hash") {
    return { type, value: await redis.hGetAll(key) };
  }

  if (type === "list") {
    return { type, value: await redis.lRange(key, 0, 499) };
  }

  if (type === "set") {
    const members = await redis.sMembers(key);
    return { type, value: members.slice(0, 500) };
  }

  if (type === "zset") {
    return { type, value: await redis.zRangeWithScores(key, 0, 499) };
  }

  if (type === "stream") {
    return { type, value: await redis.xRange(key, "-", "+", { COUNT: 500 }) };
  }

  return { type, value: null };
}

app.get("/api/health", async (req, res) => {
  try {
    await ensureRedis();
    const pong = await redis.ping();
    res.json({
      ok: pong === "PONG",
      redis: {
        host: process.env.REDIS_HOST || "127.0.0.1",
        port: Number(process.env.REDIS_PORT || 6379),
        db: Number(process.env.REDIS_DB || 8),
      }
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get("/api/summary", async (req, res) => {
  try {
    await ensureRedis();
    const [dbSize, info] = await Promise.all([
      redis.dbSize(),
      redis.info("memory")
    ]);

    const used = info.match(/used_memory_human:([^\r\n]+)/)?.[1] || "-";
    const peak = info.match(/used_memory_peak_human:([^\r\n]+)/)?.[1] || "-";
    const clients = (await redis.info("clients")).match(/connected_clients:([^\r\n]+)/)?.[1] || "-";

    res.json({
      db: Number(process.env.REDIS_DB || 8),
      keyCount: dbSize,
      usedMemory: used,
      peakMemory: peak,
      connectedClients: clients
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/keys", async (req, res) => {
  try {
    await ensureRedis();

    const match = String(req.query.search || "*").trim() || "*";
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 1000);
    let cursor = String(req.query.cursor || "0");

    const result = await redis.scan(cursor, {
      MATCH: match,
      COUNT: Math.max(limit * 2, 100)
    });

    cursor = result.cursor;
    const keys = result.keys.slice(0, limit);

    const rows = await Promise.all(keys.map(async (key) => {
      const [type, ttl] = await Promise.all([
        redis.type(key),
        redis.ttl(key)
      ]);
      return { key, type, ttl };
    }));

    rows.sort((a, b) => a.key.localeCompare(b.key));

    res.json({ cursor, keys: rows });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/key", async (req, res) => {
  try {
    const key = String(req.query.key || "");
    if (!key) return res.status(400).json({ error: "key is required" });

    const data = await getRedisValue(key);
    const ttl = await redis.ttl(key);

    res.json({
      key,
      ttl,
      ...data
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/prefixes", async (req, res) => {
  try {
    await ensureRedis();

    const counts = new Map();
    let cursor = "0";

    do {
      const scan = await redis.scan(cursor, { MATCH: "*", COUNT: 1000 });
      cursor = scan.cursor;

      for (const key of scan.keys) {
        const prefix = key.includes(":") ? key.split(":")[0] : "(no prefix)";
        counts.set(prefix, (counts.get(prefix) || 0) + 1);
      }
    } while (cursor !== "0");

    const prefixes = [...counts.entries()]
      .map(([prefix, count]) => ({ prefix, count }))
      .sort((a, b) => b.count - a.count);

    res.json(prefixes);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.get("*splat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

async function start() {
  try {
    await ensureRedis();
    console.log("============================================");
    console.log("Redis Data Dashboard");
    console.log(`Redis: ${process.env.REDIS_HOST || "127.0.0.1"}:${process.env.REDIS_PORT || 6379}`);
    console.log(`DB: ${process.env.REDIS_DB || 8}`);
    console.log(`Dashboard: http://localhost:${PORT}`);
    console.log("============================================");

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (e) {
    console.error("Unable to connect to Redis:", e.message);
    process.exit(1);
  }
}

start();
