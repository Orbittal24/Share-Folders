# Redis Data Dashboard

A lightweight dashboard for viewing Redis data, designed around the RedisInsight screen shown in the reference image.

## Features

- Redis connection status
- Database number
- Total key count
- Used/peak Redis memory
- Connected client count
- Key-prefix summary
- Search by Redis key pattern
- Redis SCAN (does not use KEYS *)
- Key type and TTL
- Click any key to view its value
- Supports STRING, HASH, LIST, SET, ZSET and STREAM
- JSON strings are automatically pretty-printed
- Refresh selected key
- Copy selected value
- Auto-refresh connection and summary every 5 seconds

## Setup

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your Redis connection details in `.env`.

Example:

```env
PORT=3200
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_DB=8
REDIS_USERNAME=
REDIS_PASSWORD=YOUR_REDIS_PASSWORD
REDIS_TLS=false
```

Do not put a real password into source code or commit `.env` to Git.

4. Install dependencies:

```bash
npm install
```

5. Start:

```bash
npm start
```

6. Open:

http://localhost:3200

## Important for large Redis databases

The dashboard uses `SCAN` rather than `KEYS *`, so it is much safer for a Redis database containing millions of keys.

The value endpoint reads at most 500 list/set/zset/stream entries at a time. String JSON values are displayed directly.
