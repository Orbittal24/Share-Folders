import pyodbc
from dotenv import load_dotenv
import os

load_dotenv()

def get_sql_server_connection():
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={os.getenv('DB_SERVER')};"
            f"DATABASE={os.getenv('DB_NAME')};"
            f"UID={os.getenv('DB_USER')};"
            f"PWD={os.getenv('DB_PASSWORD')}"
        )
        print("Connection successful")
        return conn
    except Exception as e:
        print("Connection failed:", e)
        return None

def get_sql_server_connection_insert_data():
    try:
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={os.getenv('DB_SERVER_new1')};"
            f"DATABASE={os.getenv('DB_NAME_new1')};"
            f"UID={os.getenv('DB_USER_new1')};"
            f"PWD={os.getenv('DB_PASSWORD_new1')}"
        )
        print("Connection successful")
        return conn
    except Exception as e:
        print("Connection failed:", e)
        return None


def get_sql_server_connection_get_data(version):
    try:
        if version == 'new':
            conn = pyodbc.connect(
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={os.getenv('DB_SERVER_new')};"
                f"DATABASE={os.getenv('DB_NAME_new')};"
                f"UID={os.getenv('DB_USER_new')};"
                f"PWD={os.getenv('DB_PASSWORD_new')}"
            )
            print("✅ Connected to NEW SQL Server")
        else:
            conn = pyodbc.connect(
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={os.getenv('DB_SERVER_old')};"
                f"DATABASE={os.getenv('DB_NAME_old')};"
                f"UID={os.getenv('DB_USER_old')};"
                f"PWD={os.getenv('DB_PASSWORD_old')}"
            )
            print("✅ Connected to OLD SQL Server")

        return conn

    except Exception as e:
        print("❌ Connection failed:", e)
        return None
