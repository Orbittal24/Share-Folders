import json
import asyncio
from datetime import datetime
from db.connection import (
    get_sql_server_connection_get_data,
    get_sql_server_connection_insert_data
)


# Process each row
async def process_row(row_dict, conn, insert_conn):
    await asyncio.sleep(0)  # Yield control
    try:
        pack_no = row_dict.get("battery_pack_name")
        # Assign pack_id based on prefix
        if pack_no.startswith("DJ1927-"):
            pack_id = 18
        elif pack_no.startswith("DJ2042-"):
            pack_id = 28
        elif pack_no.startswith("DJ2030-"):
            pack_id = 20
        else:
            pack_id = None  # default if no match

        if not pack_no:
            return {"status": "no_data", "pack_no": None}

        cursor = conn.cursor()
        cursor.execute("""
            SELECT packEntryDate
            FROM taco_treceability.createpack
            WHERE packQRCode = ?
        """, pack_no)

        result = cursor.fetchone()
        if result:
            columns = [column[0] for column in cursor.description]
            data = dict(zip(columns, result))

            # Insert into pack_no_details
            try:
                insert_cursor = insert_conn.cursor()
                insert_cursor.execute("""
                    INSERT INTO eol_autograph_script.dbo.pack_no_details (pack_id, pack_no, today_date, version, pack_creation_date)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    pack_id,                              # pack_id (set to NULL unless you have logic for it)
                    pack_no,                           # pack_no
                    datetime.now(),                    # today_date
                    "old",                              # version (or change as needed)
                    data.get("packEntryDate")          # pack_creation_date
                ))
                insert_conn.commit()
            except Exception as e:
                return {"status": "insert_error", "error": str(e), "pack_no": pack_no}

            return {"status": "inserted", "pack_no": pack_no, "details": data}
        else:
            return {"status": "not_found", "pack_no": pack_no}

    except Exception as e:
        return {"status": "error", "error": str(e), "pack_no": row_dict.get("battery_pack_name")}


# Fetch rows from main DB
async def fetch_and_process_rows():
    conn = None
    insert_conn = None
    try:
        conn = get_sql_server_connection_get_data("old")
        insert_conn = get_sql_server_connection_get_data("old")  # assuming insert goes into 'new' DB
        if not conn or not insert_conn:
            return json.dumps({"error": "DB connection failed"})

        cursor = conn.cursor()
        cursor.execute("SELECT battery_pack_name FROM taco_treceability.EOL_auto_graph_details")
        columns = [column[0] for column in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]

        # pass connections into process_row
        processed_rows = await asyncio.gather(*(process_row(row, conn, insert_conn) for row in rows))
        return json.dumps(processed_rows, indent=4, default=str)

    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if conn:
            conn.close()
        if insert_conn:
            insert_conn.close()


if __name__ == "__main__":
    result_json = asyncio.run(fetch_and_process_rows())
    print(result_json)
