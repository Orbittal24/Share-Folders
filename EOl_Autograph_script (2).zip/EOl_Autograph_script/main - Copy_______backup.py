import json
import asyncio
from datetime import datetime
from db.connection import (
    get_sql_server_connection,
    get_sql_server_connection_get_data,
    get_sql_server_connection_insert_data
)
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, DateTime, Text, inspect
from sqlalchemy.orm import sessionmaker

# ✅ Function to create table dynamically if not exists
# ✅ Function to create table dynamically if not exists
def create_autograph_table_if_not_exists(pack_date):
    schema_name = 'dbo'
    table_name = f"eol_autograph_{pack_date.strftime('%d-%m-%Y')}"
    metadata = MetaData(schema=schema_name)

    autograph_table = Table(
        table_name,
        metadata,
        Column('sr_no', Integer, primary_key=True),
        Column('line_id', Integer, nullable=False),
        Column('pack_id', Integer, nullable=False),
        Column('pack_no', String(50), nullable=True),
        Column('today_date', DateTime, default=datetime.utcnow, nullable=False),
        Column('parameters', String(200), nullable=True),
        Column('result', String, nullable=True),
        Column('status', String(50), nullable=True),
        Column('unit', String(100), nullable=True),
        Column('values', Text, nullable=True),  # Text for large data
        Column('graph_table', String(100), nullable=True),
        extend_existing=True
    )

    # Use your existing PyODBC connection
    sql_conn = get_sql_server_connection_insert_data()
    if not sql_conn:
        raise Exception("Target DB connection failed for table creation")

    # Wrap PyODBC connection into a SQLAlchemy engine for inspector/create_all
    engine = create_engine("mssql+pyodbc://", creator=lambda: sql_conn)

    inspector = inspect(engine)
    if not inspector.has_table(table_name, schema=schema_name):
        metadata.create_all(bind=engine, tables=[autograph_table])
        print(f"✅ Created table: {schema_name}.{table_name}")
    else:
        print(f"ℹ️ Table already exists: {schema_name}.{table_name}")

    return table_name


# ✅ Define mappings per pack_id
PACK_MAPPINGS = {
    "18": [
        ("Discharge_energy_KWH", "Discharge_Energy_KWH", "KWH", "table"),
        ("Pack_nominal_capacity", "Pack_Nominal_Capacity", "Ah", "table"),
        ("Pack_end_voltage", "Pack_End_Voltage", "Voltage", "table"),
        ("Voltage_difference_before_test", "Voltage_Difference_Before_Test", "mV", "table"),
        ("Lowest_Voltage_before_test", "Lowest_Voltage_Before_Test", "Voltage", "table"),
        ("Charging_terminal_Voltage_difference_35", "Charging_Terminal_Voltage_Difference(3.5V)", "mV", "table"),
        ("Charging_terminal_Voltage_difference_36", "Charging_Terminal_Voltage_Difference(3.65V)", "mV", "table"),
        ("Charging_Voltage_difference_after_standing", "Charging_Voltage_Difference_After_Standing", "mV", "table"),
        ("Charging_min_Voltage_after_standing", "Charging_Min_Voltage_After_Standing", "Voltage", "table"),
        ("Discharge_terminal_Voltage_difference", "Discharge_Terminal_Voltage_Difference", "mV", "table"),
        ("Discharge_temperature_max", "Discharge_Temperature_Max", "degC", "table"),
        ("Discharge_temperature_difference", "Discharge_Temperature_Difference", "degC", "table"),
        ("Discharge_Voltage_difference_after_standing", "Discharge_Voltage_Difference_After_Standing", "mV", "table"),
        ("SOC", "SOC", "%", "all"),
        ("Charging_Graph", "Charging_Graph", "-", "graph"),
        ("Discharging_Graph", "Discharging_Graph", "-", "graph"),
        ("DCIR", "DCIR", "Ohm", "table"),
        ("SOH", "SOH", "%", "table"),
        ("BMS_SW_Major_version", "BMS_SW_Major_Version", "NA", "table"),
        ("BMS_SW_Minor_version", "BMS_SW_Minor_Version", "NA", "table"),
    ],
    "28": [
        ("Discharge_energy_KWH", "Discharge_Energy_KWH", "KWH", "table"),
        ("Pack_nominal_capacity", "Pack_Nominal_Capacity", "Ah", "table"),
        ("Pack_end_voltage", "Pack_End_Voltage", "Voltage", "table"),
        ("Voltage_difference_before_test", "Voltage_Difference_Before_Test", "mV", "table"),
        ("Lowest_Voltage_before_test", "Lowest_Voltage_Before_Test", "Voltage", "table"),
        ("Charging_terminal_Voltage_difference_35", "Charging_Terminal_Voltage_Difference(3.5V)", "mV", "table"),
        ("Charging_terminal_Voltage_difference_36", "Charging_Terminal_Voltage_Difference(3.65V)", "mV", "table"),
        ("Charging_Voltage_difference_after_standing", "Charging_Voltage_Difference_After_Standing", "mV", "table"),
        ("Charging_min_Voltage_after_standing", "Charging_Min_Voltage_After_Standing", "Voltage", "table"),
        ("Discharge_terminal_Voltage_difference", "Discharge_Terminal_Voltage_Difference", "mV", "table"),
        ("Discharge_temperature_Rise", "Discharge_Temperature_Rise", "degC", "table"),
        ("Discharge_temperature_difference", "Discharge_Temperature_Difference", "degC", "table"),
        ("Discharge_Voltage_difference_after_standing", "Discharge_Voltage_Difference_After_Standing", "mV", "table"),
        ("SOC", "SOC", "%", "all"),
        ("Charging_Graph", "Charging_Graph", "-", "graph"),
        ("Discharging_Graph", "Discharging_Graph", "-", "graph"),
        ("SOH", "SOH", "%", "table"),
        ("BMS_SW_Major_version", "BMS_SW_Major_Version", "NA", "table"),
        ("BMS_SW_Minor_version", "BMS_SW_Minor_Version", "NA", "table"),
        ("BMS_SWRevision", "BMS_SWRevision", "NA", "table"),
        ("I_Pack_graph1", "I_Pack_Graph", "-", "graph"),
        ("I_Pack_graph2", "I_Pack_Graph1", "-", "graph"),
        ("ESS_BMS_FEToverheat_St_B", "ESS_BMS_FEToverheat_St_B", "B", "table"),
        ("ESS_BMS_AFEfault_St_B", "ESS_BMS_AFEfault_St_B", "B", "table"),
        ("ESS_BMS_Temperature_Act_degC", "ESS_BMS_Temperature_Act_degC", "degC", "table"),
        ("ESS_BMS_extFuseBlown_St_B", "ESS_BMS_extFuseBlown_St_B", "B", "table"),
        ("ESS_BMS_BrickTempShort_St_B", "ESS_BMS_BrickTempShort_St_B", "B", "table"),
        ("ESS_BMS_CapFulCharge_Est_Ah","ESS_BMS_CapFulCharge_Est_Ah","Ah","table"),
        ("ESS_BMS_EnergyFulCharge_Est_kWh","ESS_BMS_EnergyFulCharge_Est_kWh","Kwh","table"),
        ("ESS_BMS_PcbTemp_Act_degC","ESS_BMS_PcbTemp_Act_degC","degC","table")
    ],
    "20": [
        ("Discharge_energy_KWH", "Discharge_Energy_KWH", "KWH", "table"),
        ("Pack_nominal_capacity", "Pack_Nominal_Capacity", "Ah", "table"),
        ("Pack_end_voltage", "Pack_End_Voltage", "Voltage", "table"),
        ("Voltage_difference_before_test", "Voltage_Difference_Before_Test", "mV", "table"),
        ("Lowest_Voltage_before_test", "Lowest_Voltage_Before_Test", "Voltage", "table"),
        ("Charging_terminal_Voltage_difference_35", "Charging_Terminal_Voltage_Difference(3.5V)", "mV", "table"),
        ("Charging_terminal_Voltage_difference_36", "Charging_Terminal_Voltage_Difference(3.65V)", "mV", "table"),
        ("Charging_Voltage_difference_after_standing", "Charging_Voltage_Difference_After_Standing", "mV", "table"),
        ("Charging_min_Voltage_after_standing", "Charging_Min_Voltage_After_Standing", "Voltage", "table"),
        ("Discharge_terminal_Voltage_difference", "Discharge_Terminal_Voltage_Difference", "mV", "table"),
        ("Discharge_temperature_Rise", "Discharge_Temperature_Rise", "degC", "table"),
        ("Discharge_temperature_difference", "Discharge_Temperature_Difference", "degC", "table"),
        ("Discharge_Voltage_difference_after_standing", "Discharge_Voltage_Difference_After_Standing", "mV", "table"),
        ("SOC", "SOC", "%", "all"),
        ("Charging_Graph", "Charging_Graph", "-", "graph"),
        ("Discharging_Graph", "Discharging_Graph", "-", "graph"),
        ("SOH", "SOH", "%", "table"),
        ("BMS_SW_Major_version", "BMS_SW_Major_Version", "NA", "table"),
        ("BMS_SW_Minor_version", "BMS_SW_Minor_Version", "NA", "table"),
        ("BMS_SWRevision", "BMS_SWRevision", "NA", "table"),
        ("I_Pack_graph1", "I_Pack_Graph", "-", "graph"),
        ("I_Pack_graph2", "I_Pack_Graph1", "-", "graph"),
        ("ESS_BMS_FEToverheat_St_B", "ESS_BMS_FEToverheat_St_B", "B", "table"),
        ("ESS_BMS_AFEfault_St_B", "ESS_BMS_AFEfault_St_B", "B", "table"),
        ("ESS_BMS_Temperature_Act_degC", "ESS_BMS_Temperature_Act_degC", "degC", "table"),
        ("ESS_BMS_extFuseBlown_St_B", "ESS_BMS_extFuseBlown_St_B", "B", "table"),
        ("ESS_BMS_BrickTempShort_St_B", "ESS_BMS_BrickTempShort_St_B", "B", "table"),
        ("ESS_BMS_CapFulCharge_Est_Ah","ESS_BMS_CapFulCharge_Est_Ah","Ah","table"),
        ("ESS_BMS_EnergyFulCharge_Est_kWh","ESS_BMS_EnergyFulCharge_Est_kWh","Kwh","table"),
        ("ESS_BMS_PcbTemp_Act_degC","ESS_BMS_PcbTemp_Act_degC","degC","table")
        
    ]
}
def parse_value(value_str, default_result="-", default_status="-"):
    if not value_str:
        return default_result, default_status
    
    parts = str(value_str).strip().split()
    if len(parts) == 1:
        return parts[0], default_status
    elif len(parts) >= 2:
        return parts[0], parts[1]
    return default_result, default_status

# ✅ Insert results into dynamically created table
async def insert_results_into_db(results, pack_no, pack_date, pack_id):
    try:
        table_name_new = create_autograph_table_if_not_exists(pack_date)

        conn = get_sql_server_connection_insert_data()
        if not conn:
            print(f"❌ Target DB connection failed for pack_no: {pack_no}")
            return {"error": "Target DB connection failed", "pack_no": pack_no}

        cursor = conn.cursor()
        line_id = 5
        pack_no_new=pack_no[-6:]


        mappings = PACK_MAPPINGS.get(pack_id, [])
        if not mappings:
            print(f"⚠️ No mappings defined for pack_id {pack_id}")
            return {"status": "no_mapping", "pack_no": pack_no}

        for row in results:
            print("pack idddddddddddddd",pack_id)
            if pack_id=="28":
                for key, param_name, unit, gtable in mappings:
                    if key in row:
                        if key in ["Charging_Graph", "Discharging_Graph","I_Pack_graph1","I_Pack_graph2"]:
                            result, status = "-", "-"
                            values = "[" + str(row.get(key, "")) + "]"
                        elif key == "SOC":
                            soc_vals = row.get('SOC', "")
                            result, status = parse_value(row.get('SOC_status'))
                            values = json.dumps([{"1": [0] * len(soc_vals)}])
                        elif key == "SOH":
                            result_parts = str(row.get("SOH", "")).split()
                            result = "ALL values are: >= 100"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Major_version":
                            result_parts = str(row.get("BMS_SW_Major_version", "")).split()
                            result = "ALL values are: 9"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Minor_version":
                            result_parts = str(row.get("BMS_SW_Minor_version", "")).split()
                            result = "ALL values are: 3"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SWRevision":
                            result_parts = str(row.get("BMS_SWRevision", "")).split()
                            result = "ALL values are: 45"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_FEToverheat_St_B","ESS_BMS_AFEfault_St_B","ESS_BMS_BrickTempShort_St_B","ESS_BMS_extFuseBlown_St_B"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: 0"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_Temperature_Act_degC"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: 20 to 55"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_CapFulCharge_Est_Ah"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values in range:159 to 164"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_EnergyFulCharge_Est_kWh"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values in range:8.15 to 8.40"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_PcbTemp_Act_degC"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: <= 80"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        else:
                            result, status = parse_value(row.get(key))
                            values = "-"

                        cursor.execute("""
                            EXEC dbo.InsertEOLAutographData
                                @table_name=?,
                                @line_id=?,
                                @pack_id=?,
                                @pack_no=?,
                                @parameters=?,
                                @result=?,
                                @status=?,
                                @unit=?,
                                @values_str=?,
                                @graph_table=?
                        """, (
                            table_name_new,
                            line_id,
                            pack_id,
                            pack_no_new,
                            param_name,
                            result,
                            status,
                            unit,
                            values,
                            gtable
                        ))
                        conn.commit()
            elif pack_id=="20":
                for key, param_name, unit, gtable in mappings:
                    if key in row:
                        if key in ["Charging_Graph", "Discharging_Graph","I_Pack_graph1","I_Pack_graph2"]:
                            result, status = "-", "-"
                            values = "[" + str(row.get(key, "")) + "]"
                        elif key == "SOC":
                            soc_vals = row.get('SOC', "")
                            result, status = parse_value(row.get('SOC_status'))
                            values = json.dumps([{"1": [0] * len(soc_vals)}])
                        elif key == "SOH":
                            result_parts = str(row.get("SOH", "")).split()
                            result = "ALL values are: >= 100"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Major_version":
                            result_parts = str(row.get("BMS_SW_Major_version", "")).split()
                            result = "ALL values are: 9"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Minor_version":
                            result_parts = str(row.get("BMS_SW_Minor_version", "")).split()
                            result = "ALL values are: 4"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SWRevision":
                            result_parts = str(row.get("BMS_SWRevision", "")).split()
                            result = "ALL values are: 49"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_FEToverheat_St_B","ESS_BMS_AFEfault_St_B","ESS_BMS_BrickTempShort_St_B","ESS_BMS_extFuseBlown_St_B"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: 0"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_Temperature_Act_degC"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: 20 to 55"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_CapFulCharge_Est_Ah"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values in range:216 to 219"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_EnergyFulCharge_Est_kWh"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values in range:11 to 11.8"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key in ["ESS_BMS_PcbTemp_Act_degC"]:
                            result_parts = str(row.get(key, "")).split()
                            result = "ALL values are: <= 80"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        else:
                            result, status = parse_value(row.get(key))
                            values = "-"

                        cursor.execute("""
                            EXEC dbo.InsertEOLAutographData
                                @table_name=?,
                                @line_id=?,
                                @pack_id=?,
                                @pack_no=?,
                                @parameters=?,
                                @result=?,
                                @status=?,
                                @unit=?,
                                @values_str=?,
                                @graph_table=?
                        """, (
                            table_name_new,
                            line_id,
                            pack_id,
                            pack_no_new,
                            param_name,
                            result,
                            status,
                            unit,
                            values,
                            gtable
                        ))
                        conn.commit()
            else:
                for key, param_name, unit, gtable in mappings:
                    if key in row:
                        if key in ["Charging_Graph", "Discharging_Graph"]:
                            result, status = "-", "-"
                            values = "[" + str(row.get(key, "")) + "]"
                        elif key == "SOC":
                            soc_vals = row.get('SOC', "")
                            result, status = parse_value(row.get('SOC_status'))
                            values = json.dumps([{"1": [0] * len(soc_vals)}])
                        elif key == "SOH":
                            result_parts = str(row.get("SOH", "")).split()
                            result = "ALL values are: >= 100"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Major_version":
                            result_parts = str(row.get("BMS_SW_Major_version", "")).split()
                            result = "ALL values are: 2"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        elif key == "BMS_SW_Minor_version":
                            result_parts = str(row.get("BMS_SW_Minor_version", "")).split()
                            result = "ALL values are: 1"
                            status = result_parts[1] if len(result_parts) > 1 else "-"
                            values = "-"
                        else:
                            result, status = parse_value(row.get(key))
                            values = "-"

                        cursor.execute("""
                            EXEC dbo.InsertEOLAutographData
                                @table_name=?,
                                @line_id=?,
                                @pack_id=?,
                                @pack_no=?,
                                @parameters=?,
                                @result=?,
                                @status=?,
                                @unit=?,
                                @values_str=?,
                                @graph_table=?
                        """, (
                            table_name_new,
                            line_id,
                            pack_id,
                            pack_no_new,
                            param_name,
                            result,
                            status,
                            unit,
                            values,
                            gtable
                        ))
                        conn.commit()
        conn.close()
        print(f"✅ Inserted {len(results)} rows for pack_no: {pack_no}")
        return {"status": "success", "pack_no": pack_no}

    except Exception as e:
        return {"error": str(e), "pack_no": pack_no}


# Process each row
async def process_row(row_dict):
    await asyncio.sleep(0)
    try:
        pack_id = str(row_dict.get('pack_id'))
        pack_creation_date = row_dict.get('pack_creation_date')
        pack_no = row_dict.get('pack_no')

        pack_date_str = str(pack_creation_date)[:10]
        pack_date = datetime.strptime(pack_date_str, "%Y-%m-%d")

        print(f"Processing pack_no: {pack_no}, pack_id: {pack_id}")

        conn = get_sql_server_connection_get_data("old")
        if not conn:
            return {"error": "OLD DB connection failed", "pack_no": pack_no}

        cursor = conn.cursor()
        if pack_id == '28' or pack_id == '20':
            cursor.execute("EXEC GetEOLAutoGraphDetailsBajaj_9_2 ?", pack_no)
        else:
            cursor.execute("EXEC GetEOLAutoGraphDetails ?", pack_no)

        columns = [column[0] for column in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        conn.close()

        # Insert results into the dynamically created table
        if results:
            return await insert_results_into_db(results, pack_no, pack_date,pack_id)
        else:
            return {"status": "no_data", "pack_no": pack_no}

    except Exception as e:
        return {"error": str(e), "pack_no": row_dict.get('pack_no')}


# Fetch rows from main DB
async def fetch_and_process_rows():
    conn = get_sql_server_connection()
    if not conn:
        return json.dumps({"error": "Main DB connection failed"})

    cursor = conn.cursor()
    cursor.execute("SELECT * FROM eol_autograph_script.dbo.pack_no_details")
    columns = [column[0] for column in cursor.description]
    rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
    conn.close()

    processed_rows = await asyncio.gather(*(process_row(row) for row in rows))
    return json.dumps(processed_rows, indent=4, default=str)


if __name__ == "__main__":
    result_json = asyncio.run(fetch_and_process_rows())
    print(result_json)
