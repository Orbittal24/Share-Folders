import asyncio
import aiohttp
import pandas as pd

# Constants
URL = "http://192.168.0.112:9999/read_eol_autograph_file"
XLSX_PATH = "D:\\Vrushali\\universal MIS 14052025\\111.xlsx"
LINE_ID = 1
STATION_ID = 3017
MAX_CONCURRENT_REQUESTS = 4 # Max concurrent requests

# Read Excel sheets once and return JSON-like structure
def get_excel_sheet_data(path: str) -> dict:
    try:
        xls = pd.ExcelFile(path)
        data = {}
        for sheet_name in ["Step Layer", "Record Layer"]:
            if sheet_name in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet_name)
                data[sheet_name] = df.fillna("").to_dict(orient="records")
            else:
                print(f"⚠️ Sheet '{sheet_name}' not found.", flush=True)
        return data
    except Exception as e:
        print(f"❌ Error reading Excel file: {e}", flush=True)
        return {}

# Send one API request
async def send_request(session, index: int, semaphore: asyncio.Semaphore, file_data: dict):
    barcode = "01TMB02T100024F6P0100002"

    if not file_data:
        print(f"[{index}] ❌ No Excel data.", flush=True)
        return

    payload = {
        "pack_qrcode": barcode,
        "line_id": LINE_ID,
        "station_id": STATION_ID,
        "file_data": file_data
    }

    async with semaphore:
        print(f"[{index}] 🚀 Sending request", flush=True)
        try:
            async with session.post(URL, json=payload) as resp:
                print(f"[{index}] 🔄 Status: {resp.status}", flush=True)
                if resp.status == 200:
                    result = await resp.json()
                    print(f"[{index}] ✅ Success | Pack_ID: {result.get('Pack_ID')}", flush=True)
                else:
                    error = await resp.text()
                    print(f"[{index}] ❌ Failed | {error}", flush=True)
        except asyncio.TimeoutError:
            print(f"[{index}] ❌ Timeout occurred.", flush=True)
        except Exception as e:
            print(f"[{index}] ❌ Exception: {e}", flush=True)

# Main async runner
async def main():
    file_data = get_excel_sheet_data(XLSX_PATH)
    if not file_data:
        print("❌ Stopping: Could not read Excel data.", flush=True)
        return

    timeout = aiohttp.ClientTimeout(
        total=300,
        connect=60,
        sock_connect=60,
        sock_read=180
    )

    semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        tasks = [send_request(session, i, semaphore, file_data) for i in range(1, 51)]
        await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
